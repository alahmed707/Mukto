<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeCounter extends Model
{
    protected $fillable = ['text','counter','photo'];
}
