<div id="error"> 
	<div class="alert alert-danger validation" style="display: none;">
      <button type="button" class="close alert-close"><span>×</span></button>
            <ul class="text-left">
            </ul>
      </div>
</div><?php /**PATH D:\xampp\htdocs\charity_7\project\resources\views/includes/admin/form-error.blade.php ENDPATH**/ ?>