

<?php $__env->startSection('content'); ?>
    <div class="content-area">
        <div class="row add_lan_tab justify-content-center">
            <div class="col-lg-10">
                <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="product-description">
                                    <div class="body-area">
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tbody>
                                                    <?php
                                                        $Currency = App\Models\Currency::where('is_default',1)->first();
                                                    ?>
                                                   
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Campaign Name')); ?>:</th>
                                                        <td><?php echo e($data->campaign->campaign_name); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Name')); ?>:</th>
                                                        <td><?php echo e($data->fname); ?> <?php echo e($data->lname); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Email')); ?>:</th>
                                                        <td><?php echo e($data->email); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Number')); ?>:</th>
                                                        <td><?php echo e($data->number); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Amount')); ?>:</th>
                                                        <td><?php echo e($Currency->sign); ?><?php echo e(round( $data->donation_amount * $Currency->value ,2)); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Address')); ?>:</th>
                                                        <td><?php echo e($data->address); ?></td>
                                                    </tr>


                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Payment Type')); ?>:</th>
                                                        <td><?php echo e(strtoupper($data->payment_type)); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Donation Number')); ?>:</th>
                                                        <td><?php echo e(strtoupper($data->donation_number)); ?></td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Payment Status')); ?>:</th>
                                                        <td><?php echo e(strtoupper($data->payment_status)); ?></td>
                                                    </tr>
                                                    <?php if($data->charge_id): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Charge Id')); ?>:</th>
                                                        <td><?php echo e(strtoupper($data->charge_id)); ?></td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($data->none): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Note')); ?>:</th>
                                                        <td><?php echo e(strtoupper($data->note)); ?></td>
                                                    </tr>
                                                    <?php endif; ?>

                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/admin/campaign/donation_view.blade.php ENDPATH**/ ?>