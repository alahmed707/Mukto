

<?php $__env->startSection('content'); ?>

  <!-- Breadcrumb Area Start -->
  <div class="breadcrumb-area" style="background: url(<?php echo e($gs->breadcumb_banner ? asset('assets/images/'.$gs->breadcumb_banner):asset('assets/images/noimage.png')); ?>);">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="pagetitle">
            <?php echo e(__('Forgot Password')); ?>

          </h1>

          <ul class="pages">
              <li>
                <a href="<?php echo e(route('front.index')); ?>">
                 <?php echo e(__('Home')); ?>

                </a>
              </li>
              <li>
                <a href="<?php echo e(route('user-forgot')); ?>">
                 <?php echo e(__('Forgot Password')); ?>

                </a>
              </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Breadcrumb Area End -->
    <section class="login-signup forgot-password">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="login-area">
                        <div class="header-area forgot-passwor-area">
                            <h4 class="title"><?php echo e(__('Change Password')); ?> </h4>
                            <p class="text"> </p>
                        </div>
                        <div class="login-form">
                            <?php echo $__env->make('includes.admin.form-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>               
                            <form id="forgotform" action="<?php echo e(route('user-forgot-submit')); ?>" method="POST">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-input">
                                    <input type="email" name="email" class="User Name" placeholder="<?php echo e(__('Email')); ?>" required="">
                                    <i class="fas fa-envelope"></i>
                                </div>
                                <div class="to-login-page">
                                        <a href="<?php echo e(route('user.login')); ?>">
                                            <?php echo e(__('Login')); ?>

                                        </a>
                                </div>
                                <input class="authdata" type="hidden" value="<?php echo e(__('checking')); ?>">
                                <button type="submit" class="submit-btn"><?php echo e(__('Send')); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muktooxy/public_html/project/resources/views/user/forgot.blade.php ENDPATH**/ ?>