

<?php $__env->startSection('content'); ?>
<div class="col-lg-9">
    <div class="transaction-area">
        <div class="heading-area">
            <h3 class="title">
				<?php echo e(__('Recent Campaigns')); ?>

            </h3>
        </div>
        <div class="content">

            <div class="mr-table allproduct mt-4">
                <div class="table-responsiv">
                    <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <table id="example" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('Goal')); ?></th>
                                <th><?php echo e(__('Category')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <th><?php echo e(__('Options')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Auth::user()->campaign()->where('is_panding',1)->where('status','open')->orderby('id','desc')->take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($item->campaign_name); ?>

                                </td>
                                <td>
                                    <?php echo e($currencies->sign); ?> <?php echo e(round($item->goal * $currencies->value , 2 )); ?>

                                </td>
                                <td>
                                    <?php echo e($item->category->name); ?>

                                </td>
                                <td>
                                    <?php if($item->is_panding == 0): ?>
                                    <span class="badge badge-danger p-2 mt-2"><?php echo e(__('Panding')); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-success p-2 mt-2"><?php echo e(__('Approved')); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('user-campaign-view',$item->id)); ?>"  class="badge badge-primary p-2 btn btn-sm text-white"><?php echo e(__('View')); ?></a>
                                    <a href="<?php echo e(route('user-campaign.edit',$item->id)); ?> " class="badge btn btn-sm badge-info p-2 text-white"><?php echo e(__('Edit')); ?></a>
                                    <a  data-href="<?php echo e(route('user-campaign-delete',$item->id)); ?>" data-toggle="modal" data-target="#confirm-delete" class="text-white badge btn btn-sm badge-danger deleteData p-2 cursor-pointer"><?php echo e(__('Delete')); ?></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	$('#example').DataTable();
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/work/charity_7/project/resources/views/user/dashboard.blade.php ENDPATH**/ ?>