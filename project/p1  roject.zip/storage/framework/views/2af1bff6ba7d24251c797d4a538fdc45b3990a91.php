

<?php $__env->startSection('content'); ?>
<div class="col-lg-9">
    <div class="transaction-area">
        <div class="heading-area">
            <h3 class="title">
				<h3 class="title float-left">
                    <?php echo e(__('Campaign')); ?>

                </h3>
            </h3>
            <h3 class="title">
				<h3 class="title float-right">
                   <a href="<?php echo e(route('user-campaign.create')); ?>" class="btn btn-primary btn-round ml-2"><?php echo e(__('Create Campaign')); ?></a>
                </h3>
            </h3>
        </div>

       
        <div class="content">
            
            <div class="mr-table allproduct mt-4">
                <div class="table-responsiv">
                    <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <table id="example" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                        <thead>
                            <tr>
                                <th><?php echo e(__('Name')); ?></th>
                                <th><?php echo e(__('Goal')); ?></th>
                                <th><?php echo e(__('Funded')); ?></th>
                                <th><?php echo e(__('Status')); ?></th>
                                <th><?php echo e(__('Options')); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = Auth::user()->campaign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($item->campaign_name); ?>

                                </td>
                                <td>
                                    <?php echo e($currencies->sign); ?> <?php echo e(round($item->goal * $currencies->value , 2 )); ?>

                                </td>
                                <td>
                                    <?php echo e($currencies->sign); ?> <?php echo e(round($item->available_fund * $currencies->value , 2 )); ?>

                                </td>
                               
                                <td>
                                    <?php if($item->is_panding == 0): ?>
                                    <span class="badge badge-danger p-2 mt-2"><?php echo e(__('Panding')); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge-success p-2 mt-2"><?php echo e(__('Approved')); ?></span>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <a  data-href="<?php echo e(route('user-campaign-delete',$item->id)); ?>" data-toggle="modal" data-target="#confirm-delete" class="text-white badge btn btn-sm badge-danger deleteData p-2 cursor-pointer"><?php echo e(__('Delete')); ?></a>
                                    <a href="<?php echo e(route('user-campaign-view',$item->id)); ?>"  class="badge badge-secondary p-2 btn btn-sm text-white"><?php echo e(__('View')); ?></a>
                                    <a href="<?php echo e(route('user-campaign.edit',$item->id)); ?> " class="badge btn btn-sm badge-info p-2 text-white"><?php echo e(__('Edit')); ?></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">

            <div class="modal-header d-block text-center">
                <h4 class="modal-title d-inline-block"><?php echo e(__('Confirm Delete')); ?></h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <p class="text-center"><?php echo e(__('You are about to delete this Feature.')); ?></p>
                <p class="text-center"><?php echo e(__('Do you want to proceed')); ?>?</p>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                <a href="" class="btn btn-danger btn-ok deleteButton"><?php echo e(__('Delete')); ?></a>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $('#example').DataTable();
    
    $('.deleteData').click(function(){
        var location = $(this).attr('data-href');
        console.log(location);
         $(".deleteButton").attr("href", location);
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgenius/public_html/charity/project/resources/views/user/campaign/index.blade.php ENDPATH**/ ?>