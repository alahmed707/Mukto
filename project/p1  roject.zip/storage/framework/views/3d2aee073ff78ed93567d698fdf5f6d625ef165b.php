
<!DOCTYPE html>
<html lang="en">

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="keywords" content="<?php echo e(App\Models\Seotool::findOrFail(1)->meta_keys); ?>">
	<?php echo $__env->yieldContent('meta_content'); ?>
	<title> <?php echo e($gs->title); ?></title>
	<!-- favicon -->
	<link rel="shortcut icon" href="<?php echo e(asset('assets/images/'.$gs->favicon)); ?>" type="image/x-icon">
	<!-- bootstrap -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/bootstrap.min.css')); ?>">
	<!-- Plugin css -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/plugin.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/jquery-ui/jquery-ui.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/jquery-ui/jquery-ui.structure.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/jquery-ui/jquery-ui.theme.min.css')); ?>">

	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/pignose.calender.css')); ?>">
	<!-- stylesheet -->
	
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/style.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/styles.php?color='.str_replace('#','',$gs->colors).'&'.'secendary_color='.str_replace('#','',$gs->secendary_color))); ?>">
	<!-- responsive -->
	<link rel="stylesheet" href="<?php echo e(asset('assets/front/css/responsive.css')); ?>">

	<?php if(!empty($seo->google_analytics)): ?>
	<script>
		window.dataLayer = window.dataLayer || [];
		function gtag() {
				dataLayer.push(arguments);
		}
		gtag('js', new Date());
		gtag('config', '<?php echo e($seo->google_analytics); ?>');
	</script>
	<?php endif; ?>

	<?php if(!empty($seo->facebook_pixel)): ?>
	    <script>
			!function(f,b,e,v,n,t,s)
			{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
			n.callMethod.apply(n,arguments):n.queue.push(arguments)};
			if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
			n.queue=[];t=b.createElement(e);t.async=!0;
			t.src=v;s=b.getElementsByTagName(e)[0];
			s.parentNode.insertBefore(t,s)}(window, document,'script',
			'https://connect.facebook.net/en_US/fbevents.js');
			fbq('init', '<?php echo e($seo->facebook_pixel); ?>');
			fbq('track', 'PageView');
		  </script>
		  <noscript>
			<img height="1" width="1" style="display:none"
				 src="https://www.facebook.com/tr?id=<?php echo e($seo->facebook_pixel); ?>&ev=PageView&noscript=1"/>
		  </noscript>
	<?php endif; ?>

	<?php echo $__env->yieldContent('styles'); ?>
</head>

<body>
	<!-- preloader area start -->
	<?php if($gs->is_loader == 1): ?>
	<div class="preloader" id="preloader" style="background: url(<?php echo e(asset('assets/images/'.$gs->loader)); ?>) no-repeat scroll center center #FFF;"></div>
	<?php endif; ?>
	<!-- preloader area end -->

	<!--Main-Menu Area Start-->
	<div class="mainmenu-area">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<nav class="navbar navbar-expand-lg navbar-light">
						<a class="navbar-brand" href="<?php echo e(route('front.index')); ?>">
							<img src="<?php echo e(asset('assets/images/'.$gs->logo)); ?>" alt="logo">
						</a>
						<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main_menu" aria-controls="main_menu" aria-expanded="false" aria-label="Toggle navigation">
							<span class="navbar-toggler-icon"></span>
						</button>
						<div class="collapse navbar-collapse fixed-height" id="main_menu">
							<ul class="navbar-nav ml-auto">
								<li class="nav-item">
									<a class="nav-link <?php echo e(url()->current() == route('front.index') ? 'active' : ''); ?>" href="<?php echo e(route('front.index')); ?>"><?php echo e(__('Home')); ?></a>
								</li>

								<li class="nav-item">
									<li class="nav-item dropdown">
										<a class="nav-link <?php echo e(url()->current() == route('front.campaign') ? 'active' : ''); ?>" href="<?php echo e(route('front.campaign')); ?>">
																<?php echo e(__('Campaigns')); ?>

															</a>
										<ul class="dropdown-menu">
											<?php $__currentLoopData = App\Models\Category::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php $count = 0; foreach ($item->campaigns->where('status','open')->where('is_panding',1) as $key => $value) { $count++; } ?> <?php if($count != 0): ?>
											<li>
												<a class="dropdown-item <?php echo e(url()->current() == route('front.campaign.category',$item->slug) ? 'active' : ''); ?>" href="<?php echo e(route('front.campaign.category',$item->slug)); ?>"> <i class="fa fa-angle-double-right"></i><?php echo e($item->name); ?></a>
											</li>

											<?php endif; ?>

											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

										</ul>
									</li>
								</li>

								<!--<li class="nav-item">
									<li class="nav-item dropdown">
										<a class="nav-link <?php echo e(url()->current() == route('front.blog') ? 'active' : ''); ?>" href="<?php echo e(route('front.blog')); ?>">
																<?php echo e(__('Blog')); ?>

															</a>
										<ul class="dropdown-menu">
											<?php $__currentLoopData = App\Models\BlogCategory::where('status',1)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($cat->blogs()->count() != 0): ?>
											<li>
												<a class="dropdown-item <?php echo e(url()->current() == route('front.blogcategory',$cat->slug) ? 'active' : ''); ?>" href="<?php echo e(route('front.blogcategory',$cat->slug)); ?>"> <i class="fa fa-angle-double-right"></i><?php echo e($cat->name); ?></a>
											</li>
											<?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</li>
								</li>-->

								<?php if($gs->is_pages == 1): ?> <?php if(DB::table('pages')->count() > 0): ?>
								<li class="nav-item dropdown">
									<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
																	<?php echo e(__('Pages')); ?>

																</a>
									<ul class="dropdown-menu">
										<!--<li>
											<a class="dropdown-item <?php echo e(url()->current() == route('front.faq') ? 'active' : ''); ?>" href="<?php echo e(route('front.faq')); ?>"> <i class="fa fa-angle-double-right"></i><?php echo e(__('FAQ')); ?></a>
										</li>-->
										<?php $__currentLoopData = DB::table('pages')->orderBy('id','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<li>
											<a class="dropdown-item <?php echo e(url()->current() == route('front.page',$data->slug) ? 'active' : ''); ?>" href="<?php echo e(route('front.page',$data->slug)); ?>"> <i class="fa fa-angle-double-right"></i><?php echo e($data->title); ?></a>
										</li>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</ul>
								</li>
								<?php endif; ?> <?php endif; ?>

								<li class="nav-item">
									<a class="nav-link <?php echo e(url()->current() == route('front.contact') ? 'active' : ''); ?>" href="<?php echo e(route('front.contact')); ?>"><?php echo e(__('Contact')); ?>   </a>
								</li>

								<?php if(Auth::check()): ?>
								<li class="nav-item dropdown">
									<div class="user-image-wrapper">
										<img class="user-img" src="<?php echo e(Auth::user()->photo ? asset('assets/images/users/'.Auth::user()->photo):asset('assets/images/noimage.png')); ?>" alt="">
										<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														<?php echo e(__('My Account')); ?></a>
										<ul class="dropdown-menu">
											<li>
												<a class="dropdown-item <?php echo e(url()->current() == route('user-dashboard') ? 'active' : ''); ?>" href="<?php echo e(route('user-dashboard')); ?>"> <i class="fa fa-angle-double-right"></i> <?php echo e(__("Dashboard")); ?></a>
											</li>
											<li>
												<a class="dropdown-item <?php echo e(url()->current() == route('user-profile') ? 'active' : ''); ?>" href="<?php echo e(route('user-profile')); ?>"> <i class="fa fa-angle-double-right"></i><?php echo e(__("Profile")); ?></a>
											</li>
											<li>
												<a class="dropdown-item <?php echo e(url()->current() == route('user-reset') ? 'active' : ''); ?>" href="<?php echo e(route('user-reset')); ?>"> <i class="fa fa-angle-double-right"></i><?php echo e(__('Change Password')); ?></a>
											</li>
											<li>
												<a class="dropdown-item <?php echo e(url()->current() == route('user-logout') ? 'active' : ''); ?>" href="<?php echo e(route('user-logout')); ?>"> <i class="fa fa-angle-double-right"></i></i><?php echo e(__('Logout')); ?></a>
											</li>
										</ul>
									</div>

								</li>

								<?php else: ?>
								<li class="nav-item">
									<a class="nav-link  log-reg-btn<?php echo e(url()->current() == route('user.login') ? 'active' : ''); ?>" href="<?php echo e(route('user.login')); ?>"><?php echo e(__('Login / Register')); ?></a>
								</li>
								<?php endif; ?>

								<!--<li class="nav-item dropdown">
									<div class="user-image-wrapper">
										<a class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
										<?php echo e($currencies->name); ?></a>
										<ul class="dropdown-menu">
											<?php $__currentLoopData = DB::table('currencies')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<li>
												<a class="dropdown-item <?php echo e($currency->id == $currencies->id ? 'active' : ''); ?>" href="<?php echo e(route('front-currency-setup',$currency->id)); ?>"> <i class="fa fa-angle-double-right"></i> <?php echo e($currency->name); ?></a>
											</li>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</ul>
									</div>

								</li>-->

							</ul>
						</div>
						<div class="serch-icon-area">
							<p class="web-serch">
								<i class="fas fa-search"></i>
							</p>
						</div>

						<div class="search-form-area-mobile">
							<div class="form-wrapper">
                                <form class="search-form2" action="<?php echo e(route('front.search')); ?>" method="get">
                                    <input type="text" name="search" required placeholder="<?php echo e(__('Search what you want')); ?>">
                                </form>
                                <div class="close web-serch">
                                    <i class="fas fa-times"></i>
                                </div>
                            </div>
						</div>
					</nav>
				</div>
			</div>
		</div>
	</div>
	<!--Main-Menu Area Start-->

	<?php echo $__env->yieldContent('content'); ?>

	<!-- Footer Area Start -->
	<footer class="footer" id="footer">
		<div class="container">
			<div class="row">
				<div class="col-md-6 col-lg-4">
					<div class="footer-widget about-widget">
						<div class="footer-logo">
						<a href="<?php echo e(route('front.index')); ?>">
								<img src="<?php echo e(asset('assets/images/'.$gs->footer_logo)); ?>" alt="">
							</a>
						</div>
						<div class="text">
							<p>
								<?php echo $gs->footer; ?>

							</p>
						</div>

					</div>
				</div>
				<div class="col-md-6 col-lg-4">
					<div class="footer-widget address-widget">
						<h4 class="title">
								<?php echo e(__('Address')); ?>

							</h4>
						<ul class="about-info">
							<li>
								<p>
									<i class="fas fa-globe"></i><?php echo $pagesettings->street; ?>

								</p>
							</li>
							<li>
								<p>
									<i class="fas fa-phone"></i> <?php echo $pagesettings->phone; ?>

								</p>
							</li>
							<li>
								<p>
									<i class="far fa-envelope"></i> <?php echo $pagesettings->email; ?>

								</p>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-md-6 col-lg-4">
					<div class="footer-widget  footer-newsletter-widget">
						<h4 class="title">
									<?php echo e(__('Newsletter')); ?>

								</h4>
						<div class="newsletter-form-area">
							<form id="subscribeform" action="<?php echo e(route('front.subscribe')); ?>" method="POST">
								<?php echo e(csrf_field()); ?>

								<input type="email" id="subemail" name="email" required="" placeholder="<?php echo e(__('Enter Your Email Address')); ?>">
								<button id="sub-btn" type="submit">
									<i class="far fa-paper-plane"></i>
								</button>
							</form>
						</div>
						<div class="social-links">
							<h4 class="title">
											<?php echo e(__("We're social, connect with us:")); ?>

									</h4>
							<div class="fotter-social-links">
								<ul>
									<?php if(App\Models\Socialsetting::find(1)->f_status == 1): ?>
									<li>
										<a href="<?php echo e(App\Models\Socialsetting::find(1)->facebook); ?>" class="facebook" target="_blank">
											<i class="fab fa-facebook-f"></i>
										</a>
									</li>
									<?php endif; ?>

									<?php if(App\Models\Socialsetting::find(1)->g_status == 1): ?>
									<li>
										<a href="<?php echo e(App\Models\Socialsetting::find(1)->gplus); ?>" class="google-plus" target="_blank">
											<i class="fab fa-google-plus-g"></i>
										</a>
									</li>
									<?php endif; ?>

									<?php if(App\Models\Socialsetting::find(1)->t_status == 1): ?>
									<li>
										<a href="<?php echo e(App\Models\Socialsetting::find(1)->twitter); ?>" class="twitter" target="_blank">
											<i class="fab fa-twitter"></i>
										</a>
									</li>
									<?php endif; ?>

									<?php if(App\Models\Socialsetting::find(1)->l_status == 1): ?>
									<li>
										<a href="<?php echo e(App\Models\Socialsetting::find(1)->linkedin); ?>" class="linkedin" target="_blank">
											<i class="fab fa-linkedin-in"></i>
										</a>
									</li>
									<?php endif; ?>

									<?php if(App\Models\Socialsetting::find(1)->d_status == 1): ?>
									<li>
										<a href="<?php echo e(App\Models\Socialsetting::find(1)->dribble); ?>" class="dribbble" target="_blank">
											<i class="fab fa-dribbble"></i>
										</a>
									</li>
                            		<?php endif; ?>
								</ul>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>
		<div class="copy-bg">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<div class="content">
							<div class="content">
								<p><?php echo $gs->copyright; ?>


								</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	<!-- Footer Area End -->
	<!-- Back to Top Start -->
	<div class="bottomtotop">
		<i class="fas fa-chevron-right"></i>
	</div>
	<!-- Back to Top End -->


	<script type="text/javascript">
		var mainurl = "<?php echo e(url('/')); ?>";
		var gs  = <?php echo json_encode($gs); ?>;

		var lang  = {
          'check': '<?php echo e(__('ADD NEW')); ?>',
          'sss': '<?php echo e(__('Success !')); ?>',
      };
	  </script>

	<!-- jquery -->
	<script src="<?php echo e(asset('assets/front/js/jquery.js')); ?>"></script>
	<!-- bootstrap -->
	<script src="<?php echo e(asset('assets/front/js/bootstrap.min.js')); ?>"></script>
	<!-- popper -->
	<script src="<?php echo e(asset('assets/front/js/popper.min.js')); ?>"></script>
	<!-- Moment js -->
	<script src="<?php echo e(asset('assets/front/js/moment.min.js')); ?>"></script>
	<!-- Pignose Calender -->
	<script src="<?php echo e(asset('assets/front/js/pignose.calender.js')); ?>"></script>
	<!-- plugin js-->
	<script src="<?php echo e(asset('assets/front/js/plugin.js')); ?>"></script>
	<!-- main -->
	<script src="<?php echo e(asset('assets/front/js/notify.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/jquery-ui/jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/main.js')); ?>"></script>
	<script src="<?php echo e(asset('assets/front/js/custom.js')); ?>"></script>

	<?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/layouts/front.blade.php ENDPATH**/ ?>