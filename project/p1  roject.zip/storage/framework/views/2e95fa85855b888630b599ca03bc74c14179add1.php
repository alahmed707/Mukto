 

<?php $__env->startSection('content'); ?>  
<input type="hidden" id="headerdata" value="<?php echo e(__('FEATURE')); ?>">
<div class="content-area">
    <div class="mr-breadcrumb">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="heading"><?php echo e(__('Feature Section')); ?></h4>
                <ul class="links">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                    </li>
                    <li>
                        <a href="javascript:;"><?php echo e(__('Home Page Settings')); ?> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin-feature-index')); ?>"><?php echo e(__('Feature Section')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-area">
        <div class="row">
            <div class="col-lg-12 px-5 pt-5">
                <div class="card mb-5">
                    <div class="card-header infos">
                        <h4 class="text-white text-uppercase mb-0"><?php echo e(__('INFORMATIONS')); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                        <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form id="geniusform" action="<?php echo e(route('admin-ps-update')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="row">

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="" class="text-uppercase"><strong><?php echo e(__('Subtitle')); ?></strong></label>
                                        <input class="form-control" type="text" name="service_subtitle" value="<?php echo e(App\Models\Pagesetting::findOrFail(1)->service_subtitle); ?>" placeholder="Enter Subtitle" required>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <label for="" class="text-uppercase"><strong><?php echo e(__('Title')); ?></strong></label>
                                        <input class="form-control" type="text" name="service_title" value="<?php echo e(App\Models\Pagesetting::findOrFail(1)->service_title); ?>" placeholder="Enter Title" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-lg-2 offset-lg-5 mt-2">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block text-white text-uppercase infos"><?php echo e(__('Submit')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>
</div>


					

<?php $__env->stopSection(); ?>    


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muktooxy/public_html/project/resources/views/admin/feature/index.blade.php ENDPATH**/ ?>