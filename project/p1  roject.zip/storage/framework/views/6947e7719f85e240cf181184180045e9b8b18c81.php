
<?php echo $email_body; ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/admin/email/mailbody.blade.php ENDPATH**/ ?>