
<?php $__env->startSection('content'); ?>

			<div class="content-area">
				<div class="add-product-content">
					<div class="row">
						<div class="col-lg-12">
							<div class="product-description">
								<div class="body-area">
									<?php echo $__env->make('includes.admin.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
								<form id="geniusformdata" action="<?php echo e(route('admin.staff.update',$data->id)); ?>" method="POST" enctype="multipart/form-data">
									<?php echo e(csrf_field()); ?>


									<div class="row">
										<div class="col-lg-4">
										<div class="left-area">
											<h4 class="heading"><?php echo e(__('Staff Profile Image')); ?> *</h4>
										</div>
										</div>
										<div class="col-lg-7">
										<div class="img-upload">
											<div id="image-preview" class="img-preview" style="background: url(<?php echo e($data->photo ? asset('assets/images/admins/'.$data->photo):asset('assets/images/noimage.png')); ?>);">
												<label for="image-upload" class="img-label" id="image-label"><i class="icofont-upload-alt"></i><?php echo e(__('Upload Image')); ?></label>
                                            <input type="file" name="photo" value="<?php echo e($data->photo); ?>" class="img-upload" id="image-upload">
												</div>
												<p class="text"><?php echo e(__('Prefered Size: (600x600) or Square Sized Image')); ?></p>
										</div>
										</div>
									</div>


									<div class="row">
										<div class="col-lg-4">
											<div class="left-area">
													<h4 class="heading"><?php echo e(__('Name')); ?> *</h4>
											</div>
										</div>
										<div class="col-lg-7">
                                        <input type="text" class="input-field" name="name" placeholder="<?php echo e(__('Name')); ?>" required="" value="<?php echo e($data->name); ?>">
										</div>
									</div>


									<div class="row">
										<div class="col-lg-4">
											<div class="left-area">
													<h4 class="heading"><?php echo e(__('Email')); ?> *</h4>
											</div>
										</div>
										<div class="col-lg-7">
                                        <input type="email" class="input-field" name="email" placeholder="<?php echo e(__('Email')); ?>" required="" value="<?php echo e($data->email); ?>">
										</div>
									</div>

									<div class="row">
										<div class="col-lg-4">
											<div class="left-area">
													<h4 class="heading"><?php echo e(__('Phone')); ?> *</h4>
											</div>
										</div>
										<div class="col-lg-7">
                                        <input type="text" class="input-field" name="phone" placeholder="<?php echo e(__('Phone')); ?>" required="" value="<?php echo e($data->phone); ?>">
										</div>
									</div>

									<div class="row">
										<div class="col-lg-4">
											<div class="left-area">
												<h4 class="heading"><?php echo e(__('Admin Type')); ?> *</h4>
												<p class="sub-heading">(<?php echo e(__('In Any Language')); ?>)</p>
											</div>
										</div>
										<div class="col-lg-7">
											<select name="role">
											    <option value="administrator" <?php echo e($data->role == 'administrator' ? 'selected' : ''); ?>><?php echo e(__('Administrator')); ?></option>
											    <option value="staff" <?php echo e($data->role == 'staff' ? 'selected' : ''); ?>><?php echo e(__('Staff')); ?></option>
											</select>
										</div>
									</div>

									<div class="row">
										<div class="col-lg-4">
										<div class="left-area">
											
										</div>
										</div>
										<div class="col-lg-7">
										<button class="addProductSubmit-btn" type="submit"><?php echo e(__('Update')); ?></button>
										</div>
									</div>
								</form>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/admin/staff/edit.blade.php ENDPATH**/ ?>