<div id="error"> 
	<div class="alert alert-danger validation" style="display: none;">
      <button type="button" class="close alert-close"><span>×</span></button>
            <ul class="text-left">
            </ul>
      </div>
</div><?php /**PATH C:\wamp\htdocs\final-charity\project\resources\views/includes/admin/form-error.blade.php ENDPATH**/ ?>