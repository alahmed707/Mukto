
<?php $__env->startSection('content'); ?>      

        <div class="col-lg-9">
            <div class="account-box">
              <div class="header-area">
                <h4 class="title">
                    <?php echo e(__('Edit Profile')); ?>

                </h4>
                <a href="javascript:;" class="edit"  data-toggle="modal" data-target="#edit-account">
                    <i class="material-icons">edit</i>
                </a>
              </div>
              <div class="content">
              <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
              <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                <div class="table-responsive">
                <table>
                  <tr>
                    <td>
                        <?php echo e(__('User Name')); ?><span>:</span>
                    </td>
                    <td>
                        <?php echo e($user->name); ?>

                    </td>
                  </tr>
                  <tr>
                    <td>
                        <?php echo e(__('Email Address')); ?><span>:</span>
                    </td>
                    <td>
                         <?php echo e($user->email); ?>

                    </td>
                  </tr>
                  <tr>
                    <td>
                        <?php echo e(__('Phone Number')); ?><span>:</span>
                    </td>
                    <td>
                        <?php echo e($user->phone); ?>

                    </td>
                  </tr>
                  <tr>
                    <td>
                        <?php echo e(__('Address')); ?><span>:</span>
                    </td>
                    <td>
                        <?php echo e($user->address); ?>

                    </td>
                  </tr>
                  <tr>
                    <td>
                       <?php echo e(__('City')); ?><span>:</span>
                    </td>
                    <td>
                        <?php echo e($user->city); ?>      
                    </td>
                  </tr>
                  <tr>
                    <td>
                        <?php echo e(__('Fax')); ?><span>:</span>
                    </td>
                    <td>
                        <?php echo e($user->fax); ?>

                    </td>
                  </tr>
                  <tr>
                    <td>
                        <?php echo e(__('Zip Code')); ?><span>:</span>
                    </td>
                    <td>
                        <?php echo e($user->zip); ?>

                    </td>
                  </tr>
                </table>
                </div>
              </div>
            </div>

        </div>


  <div class="modal edit-account fade" id="edit-account" tabindex="-1" role="">
      <div class="modal-dialog modal-login" role="document">
          <div class="modal-content">
              <div class="card card-signup card-plain">
                  <div class="modal-header">
                    <div class="card-header card-header-primary text-center">
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                          <span aria-hidden="true">&times;</span>
                      </button>
  
                      <h4 class="card-title"><?php echo e(__('Edit Profile')); ?></h4>
                    </div>
                  </div>
                  <div class="modal-body">

                    <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>

                      <form class="form" method="POST" action="<?php echo e(route('user-profile-update')); ?>" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>


                      <div class="upload-image-area">
                          <div class="img">
                              <?php if($user->is_provider == 1): ?>
                                <img src="<?php echo e($user->photo ? asset($user->photo):asset('assets/images/noimage.png')); ?>">
                              <?php else: ?> 
                                <img src="<?php echo e($user->photo ? asset('assets/images/users/'.$user->photo):asset('assets/images/noimage.png')); ?>">
                              <?php endif; ?>
                          </div>
                          <a href="javascript:;" class="mybtn1 edit-profile"><?php echo e(__('Upload Image')); ?></a>
                          <input class="d-none upload" type="file" name="photo">
                      </div>


                          <div class="card-body">
                              <div class="form-group">
                                <label for="name" class="bmd-label-floating"><?php echo e(__('User Name')); ?> *</label>
                                <input type="text" class="form-control" name="name" id="name" value="<?php echo e($user->name); ?>" required="">
                              </div>

                              <div class="form-group">
                                <label for="email" class="bmd-label-floating"><?php echo e(__('Email Address')); ?> *</label>
                                <input type="email" class="form-control" name="email" id="email" value="<?php echo e($user->email); ?>" required="">
                              </div>


                              <div class="form-group">
                                <label for="phone" class="bmd-label-floating"><?php echo e(__('Phone Number')); ?> *</label>
                                <input type="tel" class="form-control" name="phone" id="phone" value="<?php echo e($user->phone); ?>" required="">
                              </div>

                              <div class="form-group">
                                <label for="address" class="bmd-label-floating"><?php echo e(__('Address')); ?> *</label>
                                <input type="text" class="form-control" name="address" id="address" value="<?php echo e($user->address); ?>" required="">
                              </div>

                              <div class="form-group">
                                <label for="city" class="bmd-label-floating"><?php echo e(__('City')); ?></label>
                                <input type="text" class="form-control" name="city" id="city" value="<?php echo e($user->city); ?>">
                              </div>

                              <div class="form-group">
                                <label for="fax" class="bmd-label-floating"><?php echo e(__('Fax')); ?></label>
                                <input type="text" class="form-control" name="fax"  id="fax" value="<?php echo e($user->fax); ?>">
                              </div>

                              <div class="form-group">
                                <label for="zip" class="bmd-label-floating"><?php echo e(__('Zip Code')); ?></label>
                                <input type="text" class="form-control" name="zip" id="zip" value="<?php echo e($user->zip); ?>">
                              </div>

                              <div class="form-group">
                                  <button type="submit" class="btn submit-btn btn-round">
                                   <?php echo e(__('Update')); ?>

                                  </button>
                              </div>
                          </div>
                      </form>
                  </div>
              </div>
          </div>
      </div>
  </div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
  
  $('.edit-profile').on('click',function(){
    $('.upload').click();

  });

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/user/profile.blade.php ENDPATH**/ ?>