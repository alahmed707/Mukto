
<?php $__env->startSection('content'); ?>

<div class="col-lg-9">
    <div class="transaction-area">
        <div class="heading-area">
          <h3 class="title">
            <?php echo e(__('Change Password')); ?>

          </h3>
        </div>

    <form id="userform" class="px-4" action="<?php echo e(route('user-reset-submit')); ?>">
      <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
              <?php echo e(csrf_field()); ?>

              <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
              <div class="row">
                <div class="col-lg-12">
                      <div class="form-group bmd-form-group">
                          <label for="cpass" class="bmd-label-floating"><?php echo e(__('Current Password')); ?>*</label>
                          <input type="password" class="form-control" id="cpass" name="cpass" required="">
                          <span class="bmd-help"><?php echo e(__('Current Password')); ?></span>
                      </div>
                </div>

                <div class="col-lg-12">
                      <div class="form-group bmd-form-group">
                          <label for="newpass" class="bmd-label-floating"><?php echo e(__('New Password')); ?>*</label>
                          <input type="password" class="form-control" id="newpass" name="newpass" required="">
                          <span class="bmd-help"><?php echo e(__('New Password')); ?></span>
                      </div>
                </div>

                <div class="col-lg-12">
                      <div class="form-group bmd-form-group">
                          <label for="renewpass" class="bmd-label-floating"><?php echo e(__('Re-Type New Password')); ?>*</label>
                          <input type="password" class="form-control" id="renewpass" name="renewpass" required="">
                          <span class="bmd-help"><?php echo e(__('Re-Type New Password')); ?></span>
                      </div>
                </div>

                <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Change')); ?></button>
                </div>
            </div>
        </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\charity_7\project\resources\views/user/reset.blade.php ENDPATH**/ ?>