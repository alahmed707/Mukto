
{!!  $email_body !!}