		<?php if(count($datas) > 0): ?>
		<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php if($data->campaign_id): ?>
				<?php if($data->usercampaignShow->is_panding == 1): ?>
					<a href="<?php echo e(route('user-campaign.index')); ?>" class="dropdown-item"><?php echo e(__('Your Campaign Is Approved')); ?></a>
				<?php endif; ?>
			<?php endif; ?>

			<?php if($data->withdraw_id): ?>
				<?php if($data->userwithdrowShow->status == 'rejected'): ?>
				<a href="<?php echo e(route('user-wwt-index')); ?>" class="dropdown-item"><?php echo e(__('Your Withdraw Request Rejected')); ?></a>
				<?php elseif($data->userwithdrowShow->status == 'completed'): ?>
					<a href="<?php echo e(route('user-wwt-index')); ?>" class="dropdown-item"><?php echo e(__('Your Withdraw Request Accepted')); ?></a>
				<?php endif; ?>
			<?php endif; ?>

			<?php if($data->conversation_id): ?>
			<a href="<?php echo e(route('user-message-show',$data->conversation_id)); ?>" class="dropdown-item"><?php echo e(__('You Have a New Message')); ?></a>
			<?php endif; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<a href="javascript:;" data-href="<?php echo e(route('customer-notf-clear')); ?>" class="dropdown-item " id="notf-clear"><?php echo e(__('Clear All')); ?></a>		
		</ul>

		<?php else: ?> 
			<a class="dropdown-item "> <?php echo e(__('No new Notification')); ?> </a>	
		<?php endif; ?>


<?php /**PATH D:\xampp\htdocs\charity_7\project\resources\views/user/notification.blade.php ENDPATH**/ ?>