<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Area Start -->
<?php if($gs->breadcumb_banner): ?>
<div class="breadcrumb-area" style="background: url(<?php echo e(asset('assets/images/'.$gs->breadcumb_banner)); ?>);">
    <div class="overlay"></div>
<?php else: ?>
<div class="breadcrumb-area">
    <div class="overlay"></div>
<?php endif; ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="pagetitle">
                    <?php echo e(__('Campaign')); ?>

                </h1>
                <ul class="pages">
                    <li>
                        <a href="<?php echo e(route('front.index')); ?>">
                            <?php echo e(__('Home')); ?>

                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.campaign')); ?>">
                            <?php echo e(__('Campaign')); ?>

                        </a>
                    </li>
                    <li class="active">
                        <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                            <?php echo e(__('Campaign Details')); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Area End -->

<!-- Causes Area Start -->

<?php if($data->meta_tag != null || $data->meta_description != null): ?>
<?php $__env->startSection('meta_content'); ?>
<meta property="og:title" content="<?php echo e($data->campaign_name); ?>" />
<meta property="og:description" content="<?php echo e($data->meta_description != null ? $data->meta_description : strip_tags($data->meta_description)); ?>" />
<meta property="og:image" content="<?php echo e(asset('assets/images/campaign'.$data->photo)); ?>" />
<meta name="keywords" content="<?php echo e($data->meta_tag); ?>">
<meta name="description" content="<?php echo e($data->meta_description); ?>">
<?php $__env->stopSection(); ?>
<?php endif; ?>

<section class="causes-details-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-md-12">
                        <div class="single-causes details">
                            <div class="img">
                                <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                            </div>
                            <div class="content">

                                <div class="top-box-wrapper">
                                    <div class="t-b-inner">
                                        <h4 class="title">
                                            <?php echo e($data->campaign_name); ?>

                                            <a href="<?php echo $data->video_link; ?>" class="video-play-btn2 mfp-iframe">
                                                <i class="fas fa-play"></i>
                                            </a>
                                            </h4>

                                            <ul class="top-meta-2">
                                                <li>
                                                    <p>
                                                        <?php
                                                        $date =  Carbon\Carbon::parse($data->end_date)
                                                        ?>
                                                        <?php echo e(__('Remaining time')); ?>: <span><?php echo e($date->diffForHumans(Carbon\Carbon::now())); ?></span>
                                                    </p>
                                                </li>
                                                <li>
                                                    <p>
                                                        <?php echo e(__('Donor(s)')); ?>: <span><?php echo e($data->donation->count()); ?></span>
                                                    </p>
                                                </li>
                                                <?php if($data->benefits): ?>
                                                <li>
                                                    <p>
                                                        <?php echo e(__('People Benefits')); ?>: <span><?php echo e($data->benefits); ?></span>
                                                    </p>
                                                </li>
                                                <?php endif; ?>
                                                <?php if($data->location): ?>
                                                <li>
                                                    <p>
                                                        <?php echo e(__('Location')); ?>: <span><?php echo e($data->location); ?></span>
                                                    </p>
                                                </li>
                                                <?php endif; ?>
                                            </ul>
                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <span><?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%</span>
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1" style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="top-meta mt-3">
                                                <div class="left">
                                                        <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($data->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                                </div>
                                                <div class="right">
                                                    <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($data->goal * $currencies->value ,2)); ?> </span>
                                                </div>
                                            </div>
                                            <div class="makea-donation shadow-none">
                                                <div class="content p-0 mt-4">
                                                    <?php if($data->preloaded_amount): ?>
                                                    <?php
                                                        $preamount = explode(',',$data->preloaded_amount);
                                                        $preamount = count($preamount);

                                                    ?>
                                                    <ul class="donet-price">
                                                        <?php $__currentLoopData = explode(',',$data->preloaded_amount); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($preamount <= 5): ?>
                                                        <li>
                                                            <a href="javascript:;" class="preloaded_amount">
                                                                <?php echo e(round($item * $currencies->value ,2)); ?>

                                                            </a>
                                                        </li>
                                                        <?php elseif($preamount >= 10): ?>
                                                            <?php if($key >= 5  && 10 > $key): ?>
                                                                <li>
                                                                    <a href="javascript:;" class="preloaded_amount">
                                                                        <?php echo e(round($item * $currencies->value ,2)); ?>

                                                                    </a>
                                                                </li>
                                                            <?php endif; ?>

                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        <li class="amount">
                                                            <p><?php echo e($currencies->sign); ?></p>
                                                            <input type="text" class="preloaded_amountValue" placeholder="<?php echo e(__('Amount')); ?>"  value="">
                                                        </li>

                                                    </ul>
                                                    <?php endif; ?>
                                            </div>
                                        </div>

                                        <form action="<?php echo e(route('front.campaign.donet',$data->slug)); ?>" method="get" class="mt-3">
                                            <input type="hidden" class="preloaded_amountValue" value="<?php echo e(Request::old('donation_amount')); ?>" name="donation_amount">
                                        <button class="mybtn1"><?php echo e(__('Donate Now')); ?></button>
                                        </form>
                                    </div>
                                </div>
                                    <div class="causes-text">
                                        <?php echo $data->description; ?>

                                    </div>


                                    <div class="footer-text social-link a2a_kit a2a_kit_size_32">
                                        <ul class="social-text">
                                            <li>
                                                <a class="facebook a2a_button_facebook" href="">
                                                  <i class="fab fa-facebook-f"></i>
                                                </a>
                                              </li>
                                                <li>
                                                    <a class="twitter a2a_button_twitter" href="">
                                                      <i class="fab fa-twitter"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="linkedin a2a_button_linkedin" href="">
                                                      <i class="fab fa-linkedin-in"></i>
                                                    </a>
                                                </li>
                                                <li>
                                                    <a class="pinterest a2a_button_pinterest" href="">
                                                      <i class="fab fa-pinterest"></i>
                                                    </a>
                                                </li>
                                                <li>

                                                <a class="a2a_dd plus" href="https://www.addtoany.com/share">
                                                    <i class="fas fa-plus"></i>
                                                  </a>
                                                </li>
                                        </ul>
                                    </div>
                                    <script async src="https://static.addtoany.com/menu/page.js"></script>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <?php
                        $count = 0;
                    ?>
                    <?php $__currentLoopData = $data->category->campaigns()->where('status','open')->take(4)->where('id', '!=',$data->id)->where('is_panding',1)->orderby('id','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(Carbon\Carbon::now() <  Carbon\Carbon::parse($item->end_date) && $item->end_after == 'date'): ?>
                    <?php
                        $count = 1;
                    ?>
                    <div class="col-md-6">
                        <a href="<?php echo e(route('front.campaign.show',$item->slug)); ?>" class="item">
                            <div class="single-causes">
                                <div class="img">
                                    <img src="<?php echo e(asset('assets/images/campaign/'.$item->photo)); ?>" alt="">
                                </div>
                                <div class="content">
                                    <span data-href="<?php echo e(route('front.campaign.donet',$item->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                    <h4 class="title">
                                        <?php echo e($item->campaign_name); ?>

                                    </h4>
                                    <p class="text">
                                        <?php echo e(substr(strip_tags($item->description),0,100)); ?>

                                    </p>

                                        <div class="progress-area">
                                            <div class="persentage">
                                                <span><?php echo e(round($item->donation->sum('donation_amount') / $item->goal * 100, 2) > 100.00  ? '100' : round($item->donation->sum('donation_amount') / $item->goal * 100, 2)); ?>%</span>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar  p-1" style="width:<?php echo e(($item->donation->sum('donation_amount') / $item->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                        <div class="top-meta mt-3">
                                            <div class="left">
                                                    <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($item->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                            </div>
                                            <div class="right">
                                                <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($item->goal * $currencies->value ,2)); ?> </span>
                                            </div>
                                        </div>


                                </div>
                            </div>
                        </a>
                    </div>

                    <?php elseif($item->goal > $item->available_fund && $item->end_after == 'goal'): ?>
                    <?php
                        $count = 1;
                    ?>
                        <div class="col-md-6">
                            <a href="<?php echo e(route('front.campaign.show',$item->slug)); ?>" class="item">
                                <div class="single-causes">
                                    <div class="img">
                                        <img src="<?php echo e(asset('assets/images/campaign/'.$item->photo)); ?>" alt="">
                                    </div>
                                    <div class="content">
                                        <span data-href="<?php echo e(route('front.campaign.donet',$item->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                        <h4 class="title">
                                            <?php echo e($item->campaign_name); ?>

                                        </h4>
                                        <p class="text">
                                            <?php echo e(substr(strip_tags($item->description),0,100)); ?>

                                        </p>

                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <span><?php echo e(round($item->donation->sum('donation_amount') / $item->goal * 100, 2) > 100.00  ? '100' : round($item->donation->sum('donation_amount') / $item->goal * 100, 2)); ?>%</span>
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1" style="width:<?php echo e(($item->donation->sum('donation_amount') / $item->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="top-meta mt-3">
                                                <div class="left">
                                                        <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($item->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                                </div>
                                                <div class="right">
                                                    <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($item->goal * $currencies->value ,2)); ?> </span>
                                                </div>
                                            </div>


                                    </div>
                                </div>
                            </a>
                        </div>
                    <?php endif; ?>


                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="recent-causes-widget">
                    <h4 class="title">
                        <?php echo e(__('Latest Campaign')); ?>

                    </h4>
                    <span class="separator"></span>
                    <ul class="post-list">
                        <?php $__currentLoopData = $latesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Carbon\Carbon::now() < Carbon\Carbon::parse($data->end_date) && $data->end_after == 'date'): ?>

                            <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                                <li>
                                    <div class="post">
                                        <div class="post-img">
                                            <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                                        </div>
                                        <div class="post-details">
                                            <h4 class="post-title">
                                                <?php echo e($data->campaign_name); ?>

                                                <p class="time-left">
                                                    - (<?php echo e($data->end_date); ?>)
                                                </p>
                                            </h4>



                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1"
                                                        style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%"
                                                        role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </a>
                            <?php elseif($data->goal > $data->available_fund && $data->end_after == 'goal'): ?>
                            <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                                <li>
                                    <div class="post">
                                        <div class="post-img">
                                            <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                                        </div>
                                        <div class="post-details">

                                            <h4 class="post-title">
                                                <?php echo e($data->campaign_name); ?>

                                                <p class="time-left">
                                                   - (<?php echo e($data->end_date); ?>)
                                                </p>
                                            </h4>



                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1"
                                                        style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%"
                                                        role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </a>

                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php if($count == 0): ?>
                            <li>
                                <div class="post">
                                    <div class="post-details">
                                        <h4 class="post-title text-center">
                                            <?php echo e(__('No Campaign')); ?>

                                        </h4>
                                    </div>
                                </div>
                            </li>
                            <?php endif; ?>
                    </ul>
                </div>
                <div class="categori-widget">
                    <h4 class="title"><?php echo e(__('Categories')); ?></h4>
                    <span class="separator"></span>
                    <ul class="categori-list">
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $count = 0;
                        foreach ($item->campaigns->where('status','open')->where('is_panding',1) as $key => $value) {
                        if($value->goal > $value->available_fund && $value->end_after == 'goal'){
                        $count++;
                        }elseif(Carbon\Carbon::now() < Carbon\Carbon::parse($value->end_date) && $value->end_after ==
                            'date'){
                            $count++;
                            }
                        }
                        ?>
                        <?php if($count != 0): ?>
                        <li>
                            <a href="<?php echo e(route('front.campaign.category',$item->slug)); ?>" <?php echo $item->slug == Request::route('slug') ?
                                'class="active"':''; ?> >
                                <span><?php echo e($item->name); ?></span>
                                <span>(<?php echo e($count); ?>)</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
                <div class="tags-widget">
                    <h4 class="title"><?php echo e(__('Tags')); ?></h4>
                    <span class="separator"></span>
                    <ul class="tags-list">

                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($tag): ?>
                        <li>
                            <a href="<?php echo e(route('front.campaign.slug',$tag)); ?>"><?php echo e($tag); ?> </a>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Causes Area End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgenius/public_html/charity/project/resources/views/front/campaign_show.blade.php ENDPATH**/ ?>