<?php $__env->startSection('content'); ?>
<input type="hidden" id="headerdata" value="FAQ">
<div class="content-area">
    <div class="mr-breadcrumb">
        <div class="row">
            <div class="col-lg-12">
                <ul class="links">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                    </li>
                    <li>
                        <a href="javascript:;"><?php echo e(__('Menu Page Settings')); ?> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin-faq-index')); ?>"><?php echo e(__('FAQ')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="product-area">

        <div class="row">
            <div class="col-lg-12 px-5 pt-5">
                <div class="card mb-5">
                    <div class="card-header infos">
                        <h4 class="text-white text-uppercase mb-0"><?php echo e(__('Meta Informations')); ?></h4>

                    </div>
                    <br>
                    <div class="card-body">
                        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                        <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form id="geniusform" action="<?php echo e(route('admin-ps-update')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>


                            <div class="row">
                                <div class="col-lg-4">
                                  <div class="left-area">
                                      <h4 class="heading"><?php echo e(__('Current Featured Image')); ?> *</h4>
                                  </div>
                                </div>
                                <div class="col-lg-7">
                                  <div class="img-upload">
                                      <div id="image-preview" class="img-preview" style="background: url(<?php echo e($data->faq_photo ? asset('assets/images/'.$data->faq_photo): asset('assets/images/noimage.png')); ?>);">
                                          <label for="image-upload" class="img-label" id="image-label"><i class="icofont-upload-alt"></i><?php echo e(__('Upload Image')); ?></label>
                                          <input type="file" name="faq_photo" class="img-upload" id="image-upload">
                                        </div>
                                        <p class="text"><?php echo e(__('Prefered Size: (600x600) or Square Sized Image')); ?></p>
                                  </div>
                                </div>
                              </div>

                            <div class="row">

                                <div class="col-lg-2 offset-lg-5 mt-2">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-block text-white text-uppercase infos"><?php echo e(__('Submit')); ?></button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="mr-table allproduct">
                    <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="table-responsiv">
                        <table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                            <thead>
                                <tr>
                                    <th width="30%"><?php echo e(__('Faq Title')); ?></th>
                                    <th width="50%"><?php echo e(__('Faq Details')); ?></th>
                                    <th><?php echo e(__('Actions')); ?></th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="modal1" tabindex="-1" role="dialog" aria-labelledby="modal1" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="submit-loader">
                <img src="<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>" alt="">
            </div>
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><?php echo e(__('Close')); ?></button>
            </div>
        </div>
    </div>

</div>

 

<div class="modal fade" id="confirm-delete">
    <div class="modal-dialog">
        <div class="modal-content">

            <!-- Modal Header -->
            <div class="modal-header text-center">
                <h4 class="modal-title w-100"><?php echo e(__('Confirm Delete')); ?></h4>
            </div>

            <!-- Modal body -->
            <div class="modal-body">
                <p class="text-center"><?php echo e(__('You are about to delete this Faq.')); ?></p>
                <p class="text-center"><?php echo e(__('Do you want to proceed?')); ?></p>
            </div>

            <!-- Modal footer -->
            <div class="modal-footer justify-content-center">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo e(__('Cancel')); ?></button>
                <a class="btn btn-danger btn-ok"><?php echo e(__('Delete')); ?></a>
            </div>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>




    <script type="text/javascript">

		var table = $('#geniustable').DataTable({
			   ordering: false,
               processing: true,
               serverSide: true,
               ajax: '<?php echo e(route('admin-faq-datatables')); ?>',
               columns: [
                        { data: 'title', name: 'title' },
                        { data: 'details', name: 'details' },
            			{ data: 'action', searchable: false, orderable: false }

                     ],
               language : {
                	processing: '<img src="<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>">'
                }
            });

      	$(function() {
        $(".btn-area").append('<div class="col-sm-4 table-contents">'+
        	'<a class="add-btn" data-href="<?php echo e(route('admin-faq-create')); ?>" id="add-data" data-toggle="modal" data-target="#modal1">'+
          '<i class="fas fa-plus"></i> <?php echo e(__('Add New Faq')); ?>'+
          '</a>'+
          '</div>');
      });

    </script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\charity_7\project\resources\views/admin/faq/index.blade.php ENDPATH**/ ?>