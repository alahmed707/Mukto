<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Area Start -->
<?php if($gs->breadcumb_banner): ?>
<div class="breadcrumb-area" style="background: url(<?php echo e(asset('assets/images/'.$gs->breadcumb_banner)); ?>);">
    <div class="overlay"></div>
<?php else: ?>
<div class="breadcrumb-area">
    <div class="overlay"></div>
<?php endif; ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="pagetitle">
                    <?php echo e(__('Donate')); ?>

                </h1>
                <ul class="pages">
                    <li>
                        <a href="<?php echo e(route('front.index')); ?>">
                           <?php echo e(__('Home')); ?>

                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('front.campaign')); ?>">
                            <?php echo e(__('Campaign')); ?>

                        </a>
                    </li>

                    <li class="active">
                        <a href="<?php echo e(route('front.campaign.donet',$CampaignData->slug)); ?>">
                            <?php echo e(__('Donate')); ?>

                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Breadcrumb Area End -->

<!-- Causes Area Start -->
<section class="causes-details-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <div class="single-causes details donate-page mb-0">
                    <div class="img">
                        <img src="<?php echo e(asset('assets/images/campaign/'.$CampaignData->photo)); ?>" alt="">
                    </div>
                    <div class="content">

                        <div class="top-box-wrapper pb-0">
                            <div class="t-b-inner">
                                <h4 class="title">
                                    <?php echo e(substr(strip_tags($CampaignData->description),0,100)); ?>


                                    </h4>
                                    <div class="progress-area">
                                        <div class="persentage">
                                            <span><?php echo e(round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2) > 100.00  ? '100' : round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2)); ?>%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar  p-1" style="width:<?php echo e(($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                    <div class="top-meta mt-3">
                                        <div class="left">
                                                <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                        </div>
                                        <div class="right">
                                            <?php echo e(__('Goal')); ?> :  <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->goal * $currencies->value ,2)); ?> </span>
                                        </div>
                                    </div>
                                    <div class="causes-details2">
                                        <?php if($errors->any()): ?>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="mb-2">
                                                    <ul>
                                                        <li class="aleart alert-danger p-2 mb-2"><?php echo e($error); ?></li>
                                                    </ul>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>

                                        <?php if(session()->has('message')): ?>
                                        <div class="alert alert-success">
                                            <?php echo e(session()->get('message')); ?>

                                        </div>
                                        <?php endif; ?>

                                        <?php if(session()->has('unsuccess')): ?>
                                        <div class="alert alert-danger">
                                            <?php echo e(session()->get('unsuccess')); ?>

                                        </div>
                                        <?php endif; ?>
                                        <div class="makea-donation">
                                            <div class="top-header-area">
                                                <h4 class="title"><?php echo e(__('Make a Donation')); ?></h4>
                                                <p class="text"><?php echo e(__('How much would you like to donate?')); ?></p>
                                            </div>
                                                <div class="content">
                                                <p class="text-mutedmb-4"><?php echo e($CampaignData->campaign_name); ?></p>
                                                    <?php if($CampaignData->preloaded_amount): ?>
                                                        <?php if(!$amount): ?>
                                                        <?php
                                                        $preamount = explode(',',$CampaignData->preloaded_amount);
                                                        $preamount = count($preamount);
                                                        ?>
                                                        <ul class="donet-price">
                                                            <?php $__currentLoopData = explode(',',$CampaignData->preloaded_amount); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($preamount <= 5): ?>
                                                            <li>
                                                                <a href="javascript:;" class="preloaded_amount">
                                                                    <?php echo e(round($item * $currencies->value ,2)); ?>

                                                                </a>
                                                            </li>
                                                            <?php elseif($preamount >= 10): ?>
                                                                    <?php if($key >= 5  && 10 > $key): ?>
                                                                        <li>
                                                                            <a href="javascript:;" class="preloaded_amount">
                                                                                <?php echo e(round($item * $currencies->value ,2)); ?>

                                                                            </a>
                                                                        </li>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="amount">
                                                                <p><?php echo e($currencies->sign); ?></p>
                                                            <input type="text" class="preloaded_amountValue" placeholder="<?php echo e(__('Amount')); ?>"  value="">
                                                            </li>
                                                        </ul>
                                                        <?php else: ?>
                                                            <p class="text muted text-center"><?php echo e(__('Amount')); ?> = <strong><?php echo e($currencies->sign); ?> <input type="text" class="preloaded_amountValue"  value="<?php echo e($amount); ?>"></strong></p>
                                                        <?php endif; ?>


                                                    <?php else: ?>
                                                    <ul class="donet-price">
                                                        <li class="amount">
                                                            <p><?php echo e($currencies->sign); ?></p>
                                                        <input type="text" class="preloaded_amountValue " placeholder="<?php echo e(__('Amount')); ?>"  value="">
                                                        </li>
                                                    </ul>

                                                    <?php endif; ?>


                                                    <div class="donation-form mt-5">
                                                        <?php
                                                            $user = Auth::user();
                                                        ?>
                                                        <form class="pay-form" action=""  method="post">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="lname" required class="input-field" placeholder="<?php echo e(__('Enter Your First Name')); ?>" value="<?php echo e($user ? $user->name : Request::old('fname')); ?>">
                                                            <input type="hidden" value="<?php echo e($CampaignData->id); ?>" name="campaign_id">
                                                            <input type="hidden" class="preloaded_amountValue" value="<?php echo e($amount ? $amount : Request::old('donation_amount')); ?>" name="donation_amount">
                                                            <input type="hidden"  value="<?php echo e($CampaignData->user_id); ?>" name="user_id">
                                                            <div class="AnonymousForm">
                                                            <div class="row mt-3">
                                                                <div class="col-lg-6">
                                                                    <input type="text" name="fname" required class="input-field" placeholder="<?php echo e(__('Enter Your First Name')); ?>" value="<?php echo e($user ? $user->name : Request::old('fname')); ?>">
                                                                </div>
                                                                 <div class="col-lg-6">
                                                                        <input type="text" name="number" required class="input-field" placeholder="<?php echo e(__('Enter Your Phone Number')); ?>" value="<?php echo e($user ? $user->phone : Request::old('number')); ?>">
                                                                </div>
                                                                
                                                            </div>
                                                            <div class="row">
                                                               
                                                                <div class="col-lg-6">
                                                                        <input type="text" name="email" required  class="input-field" placeholder="<?php echo e(__('Enter Your Email Address')); ?>" value="<?php echo e($user ? $user->email: Request::old('email')); ?>">
                                                                </div>
                                                                <div class="col-lg-6">
                                                                        <input type="text" name="address" required  class="input-field" placeholder="<?php echo e(__('Enter Your Address')); ?>" value="<?php echo e($user ? $user->address : Request::old('address')); ?>">
                                                                </div>
                                                            </div>
                                                              <div class="row">
                                                               
                                                                <div class="col-lg-12">
                                                                        <input type="text" name="note" class="input-field" placeholder="<?php echo e(__('Enter Your Notes')); ?>" value="<?php echo e(Request::old('note')); ?>">
                                                                </div>
                                                            
                                                            </div>
                                                            
                                                        </div>
                                                        <div class="row">
                                                                
                                                               
                                                                <div class="col-lg-6">
                                                                    <select name="method" id="method" class="option input-field" required="">
                                                                        <option value="" data-form="" data-show="no" data-val="" data-href=""><?php echo e(__('Select an option')); ?></option>
                                                                        <?php $__currentLoopData = $gateways; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paydata): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <option value="<?php echo e($paydata->name); ?>" data-form="<?php echo e($paydata->showCheckoutLink()); ?>" data-show="<?php echo e($paydata->showForm()); ?>" data-href="<?php echo e(route('front.load.payment',['slug1' => $paydata->showKeyword(),'slug2' => $paydata->id])); ?>" data-val="<?php echo e($paydata->keyword); ?>">
                                                                                <?php echo e($paydata->name); ?>

                                                                            </option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                            <div class="row padiingG">
                                                                
                                                            </div>
                                                            <div id="payments" class="d-none">

                                                            </div>

                                                            <input type="hidden" name="cmd" value="_xclick">
                                                            <input type="hidden" name="no_note" value="1">
                                                            <input type="hidden" name="lc" value="UK">
                                                            <input type="hidden" name="currency_code" id="currency_name" value="<?php echo e($currencies->name); ?>">
                                                            <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest">
                                                            <input type="hidden" name="sub" id="sub" value="0">

                                                    </div>
                                                   <div class="submit-btn-area d-flex align-items-center">
                                                    <button type="submit" class="mybtn1 mr-4" id="final-btn"><?php echo e(__('Donate Now')); ?></button>
                                                    <input type="checkbox" name="aninumasType" id="check" class="mr-3 ml-2"   value="1"> <label for="check" class="mb-0 pb-0"><?php echo e(__('Anonymous Donation')); ?></label>
                                                   </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-4">
                <div class="recent-causes-widget">
                    <h4 class="title">
                        <?php echo e(__('Latest Campaign')); ?>

                    </h4>
                    <span class="separator"></span>
                    <ul class="post-list">
                        <?php $__currentLoopData = $latesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Carbon\Carbon::now() < Carbon\Carbon::parse($data->end_date) && $data->end_after == 'date'): ?>

                            <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                                <li>
                                    <div class="post">
                                        <div class="post-img">
                                            <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                                        </div>
                                        <div class="post-details">
                                            <h4 class="post-title">
                                                <?php echo e($data->campaign_name); ?>

                                                <p class="time-left">
                                                    - (<?php echo e($data->end_date); ?>)
                                                </p>
                                            </h4>



                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1"
                                                        style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%"
                                                        role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </a>
                            <?php elseif($data->goal > $data->available_fund && $data->end_after == 'goal'): ?>
                            <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                                <li>
                                    <div class="post">
                                        <div class="post-img">
                                            <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                                        </div>
                                        <div class="post-details">

                                            <h4 class="post-title">
                                                <?php echo e($data->campaign_name); ?>

                                                <p class="time-left">
                                                   - (<?php echo e($data->end_date); ?>)
                                                </p>
                                            </h4>



                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1"
                                                        style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%"
                                                        role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            </a>

                            <?php endif; ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <div class="categori-widget">
                    <h4 class="title"><?php echo e(__('Categories')); ?></h4>
                    <span class="separator"></span>
                    <ul class="categori-list">
                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $count = 0;
                        foreach ($item->campaigns->where('status','open')->where('is_panding',1) as $key => $value) {
                        if($value->goal > $value->available_fund && $value->end_after == 'goal'){
                        $count++;
                        }elseif(Carbon\Carbon::now() < Carbon\Carbon::parse($value->end_date) && $value->end_after ==
                            'date'){
                            $count++;
                            }
                        }
                        ?>
                        <?php if($count != 0): ?>
                        <li>
                            <a href="<?php echo e(route('front.campaign.category',$item->slug)); ?>" <?php echo $item->slug == Request::route('slug') ?
                                'class="active"':''; ?> >
                                <span><?php echo e($item->name); ?></span>
                                <span>(<?php echo e($count); ?>)</span>
                            </a>
                        </li>
                        <?php endif; ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                </div>
                <div class="tags-widget">
                    <h4 class="title"><?php echo e(__('Tags')); ?></h4>
                    <span class="separator"></span>
                    <ul class="tags-list">

                        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($tag): ?>
                        <li>
                            <a href="<?php echo e(route('front.campaign.slug',$tag)); ?>"><?php echo e($tag); ?> </a>
                        </li>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Causes Area End -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript" src="<?php echo e(asset('assets/front/js/payvalid.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/front/js/paymin.js')); ?>"></script>

<script type="text/javascript" src="<?php echo e(asset('assets/front/js/payform.js')); ?>"></script>

<script src="https://js.paystack.co/v1/inline.js"></script>

<script src="//voguepay.com/js/voguepay.js"></script>

<script src="https://www.2checkout.com/checkout/api/2co.min.js"></script>

<script type="text/javascript" src="https://js.stripe.com/v2/"></script>

<script src="https://secure.mlstatic.com/sdk/javascript/v1/mercadopago.js"></script>



<script>

    $('#method').on('change',function(){
    var val  = $(this).find(':selected').attr('data-val');
    var form = $(this).find(':selected').attr('data-form');
    var show = $(this).find(':selected').attr('data-show');
    var href = $(this).find(':selected').attr('data-href');


    if(show == "yes"){
        $('#payments').removeClass('d-none');
    }else{
        $('#payments').addClass('d-none');
    }

    if(val == 'paystack'){
        $('.pay-form').prop('id','paystack');
		$('.preloaded_amountValue').prop('name','amount');
        }

		else if(val == 'voguepay'){
        $('.preloaded_amountValue').prop('name','amount');
		$('.pay-form').prop('id','voguepay');
		}
		else if(val == 'mercadopago'){
			$('.pay-form').prop('id','mercadopago');
        }

		else if(val == '2checkout'){
			$('.pay-form').prop('id','twocheckout');

        }

		else {
	        $('.pay-form').prop('id','deposit-form');
		}


    $('#payments').load(href);
    $('.pay-form').attr('action',form);
});

$(document).on('submit','#paystack',function(){
            var val = $('#sub').val();
            if(val == 0){
                var total = $('.preloaded_amountValue').val();
                var curr =  $('#currency_name').val();
                total = Math.round(total);
                var handler = PaystackPop.setup({
                key: '<?php echo e($paystack['key']); ?>',
                email: 'abc@gmail.com',
                amount: total * 100,
                currency: curr,
                ref: ''+Math.floor((Math.random() * 1000000000) + 1),
                    callback: function(response){
                        $('#ref_id').val(response.reference);
                        $('#sub').val('1');
                        $('#final-btn').click();
                    },
                    onClose: function(){
                        window.location.reload();
                    }
                });
                handler.openIframe();
                 return false;

            }
            else {
                return true;
            }
		});

        $(document).on('submit','#voguepay',function(e){
            var val = $('#sub').val();
            if(val == 0)
            {
                var total = $('.preloaded_amountValue').val();
                var curr =  $('#currency_name').val();
                e.preventDefault();
                Voguepay.init({
                    v_merchant_id: '<?php echo e($voguepay["merchant_id"]); ?>',
                    total: total,
                    cur: curr,
                    merchant_ref: 'ref'+Math.floor((Math.random() * 1000000000) + 1),
                    memo:'<?php echo e($gs->title); ?> Order',
                    developer_code: '<?php echo e($voguepay["developer_code"]); ?>',
                    store_id:'<?php echo e(Auth::user() ? Auth::user()->id : 0); ?>',
                    closed:function(){
                        var newval = $('#sub').val();
                        if(newval == 0){
                            window.location.reload();
                        }
                        else {
                            $('#final-btn').click();
                        }
                    },
                    success:function(transaction_id){
                        $('#ref_id').val(transaction_id);
                        $('#sub').val('1');
                    },
                    failed:function(){
                        window.location.reload();
                    }
                });
                return false;
            }
            else {
                return true;
            }
		});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgenius/public_html/charity/project/resources/views/front/campaign_donet.blade.php ENDPATH**/ ?>