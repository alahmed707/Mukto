<?php $__env->startSection('content'); ?>
<section class="hero-area" style="background: url(<?php echo e($page_data->homepage_photo ?  asset('assets/images/home-background/'.$page_data->homepage_photo): asset('assets/front/images/hero-bg.png')); ?>);">
<?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<div class="overlay"></div>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7">
				<div class="content">
					<h5 class="sub-title">
						<?php echo e($page_data->homepage_subtitle); ?>

					</h5>
					<h1 class="title">
						<?php echo e($page_data->homepage_title); ?>

					</h1>
					<p class="text">
						<?php echo e($page_data->homepage_descriptin); ?>

					</p>
					<div class="links-area">
						<?php if($page_data->homepage_link1): ?>
						<a class="link left" href="<?php echo e($page_data->homepage_link1); ?>"><?php echo e($page_data->homepage_button1); ?></a>
						<?php endif; ?>
						<?php if($page_data->homepage_link2): ?>
						<a class="link left" href="<?php echo e($page_data->homepage_link2); ?>"><?php echo e($page_data->homepage_button2); ?></a>
						<?php endif; ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Hero Area End -->


<?php if($ps->ccounter == 1): ?>
<!-- Statistics Area Start -->
<section class="statistics">
	<div class="container">
		<div class="row align-items-center">
            <div class="col-lg-6">
				<div class="video-area">
					<img class="video-bg" src="<?php echo e(asset('assets/images/'. $ps->counter_image)); ?>" alt="">
					<div class="video-button">
						<a href="<?php echo $pagesettings->counter_video_link; ?>" class="video-play-btn mfp-iframe">
							<i class="fas fa-play"></i>
						</a>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="section-heading">
					<div class="sub-title">
						<?php echo $pagesettings->counter_subtitle; ?>

					</div>
					<h4 class="section-title">
						<?php echo $pagesettings->counter_title; ?>

					</h4>
				</div>
				<div class="row">
					<?php $__currentLoopData = $homeCounterData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="col-sm-6">
						<div class="single-statistics-box">
							<div class="left">
								<img src="<?php echo e(asset('assets/images/counter/'.$counter->photo)); ?>" alt="">
							</div>
							<div class="right">
								<h4 class="num">
									<?php echo e($counter->counter); ?>

								</h4>
								<p class="title">
									<?php echo e($counter->text); ?>

								</p>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>

		</div>
	</div>
</section>
<!-- Statistics Area End -->
<?php endif; ?>
<?php if($ps->cservice == 1): ?>
	<!-- About Area Start -->
<section class="about-area">
	<div class="container">
		<div class="row">
			<?php $__currentLoopData = $servicesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="col-lg-xl col-md-6">
				<div class="single-info-box">
					<div class="icon">
                        <img src="<?php echo e(asset('assets/images/services/'.$service->photo)); ?>" alt="">
					</div>
					<div class="content">
                        <h4 class="title">
                            <?php echo e($service->title); ?>

                        </h4>
                        <p class="text">
                            <?php echo $service->details; ?>

                        </p>
                    </div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</section>
<!-- About Area Start -->
<?php endif; ?>

<!-- Counter Area Start -->
<section class="counter-area">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $homeCounterData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $counter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6">
                <div class="single-counter text-center"  >
                    <div class="counter-icon mb-25">
                        <img src="<?php echo e(asset('assets/images/counter/'.$counter->photo)); ?>" alt="">
                    </div>
                    <div class="counter-text">
                        <h3><span class="counter"><?php echo e($counter->counter); ?></span>k+</h3>
                        <p><?php echo e($counter->text); ?></p>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- Counter Area End -->


<?php if($ps->cfeature == 1): ?>
	<!-- Causes Area Start -->
<section class="causes feature-causes">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="section-heading text-center">
					<p class="sub-title">
						<?php echo $pagesettings->service_subtitle; ?>

					</p>
					<h4 class="section-title">
						<?php echo $pagesettings->service_title; ?>

					</h4>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="featured-causes-slider-two">
                    <?php $__currentLoopData = $CampaignDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CampaignData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Carbon\Carbon::now() <  Carbon\Carbon::parse($CampaignData->end_date) && $CampaignData->end_after == 'date'): ?>
                        <div class="slider-item">
                            <a href="<?php echo e(route('front.campaign.show',$CampaignData->slug)); ?>" class="item">
                                <div class="single-causes">
                                    <div class="img">
                                        <img src="<?php echo e(asset('assets/images/campaign/'.$CampaignData->photo)); ?>" alt="">
                                    </div>
                                    <div class="content">
                                        <span data-href="<?php echo e(route('front.campaign.donet',$CampaignData->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                        <h4 class="title">
                                            <?php echo e($CampaignData->campaign_name); ?>

                                        </h4>
                                        <p class="text">
                                            <?php echo e(substr(strip_tags($CampaignData->description),0,100)); ?>

                                        </p>

                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <span><?php echo e(round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2) > 100.00  ? '100' : round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2)); ?>%</span>
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1" style="width:<?php echo e(($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="top-meta mt-3">
                                                <div class="left">
                                                        <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                                </div>
                                                <div class="right">
                                                    <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->goal * $currencies->value ,2)); ?> </span>
                                                </div>
                                            </div>


                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php elseif($CampaignData->goal > $CampaignData->available_fund && $CampaignData->end_after == 'goal'): ?>
                        <div class="slider-item">
                            <a href="<?php echo e(route('front.campaign.show',$CampaignData->slug)); ?>" class="item">
                                <div class="single-causes">
                                    <div class="img">
                                        <img src="<?php echo e(asset('assets/images/campaign/'.$CampaignData->photo)); ?>" alt="">
                                    </div>
                                    <div class="content">
                                        <span data-href="<?php echo e(route('front.campaign.donet',$CampaignData->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                        <h4 class="title">
                                            <?php echo e($CampaignData->campaign_name); ?>

                                        </h4>
                                        <p class="text">
                                            <?php echo e(substr(strip_tags($CampaignData->description),0,100)); ?>

                                        </p>

                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <span><?php echo e(round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2) > 100.00  ? '100' : round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2)); ?>%</span>
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1" style="width:<?php echo e(($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="top-meta mt-3">
                                                <div class="left">
                                                        <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                                </div>
                                                <div class="right">
                                                    <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->goal * $currencies->value ,2)); ?> </span>
                                                </div>
                                            </div>


                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Causes Area End -->
<?php endif; ?>
<?php if($ps->cfeature == 1): ?>
	<!-- Causes Area Start -->
<section class="causes bg-gray">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="section-heading text-center">
					<p class="sub-title">
						<?php echo $pagesettings->service_subtitle; ?>

					</p>
					<h4 class="section-title">
						<?php echo e(__('Latest Campain')); ?>

					</h4>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="featured-causes-slider">
                    <?php $__currentLoopData = $CampaignDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CampaignData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Carbon\Carbon::now() <  Carbon\Carbon::parse($CampaignData->end_date) && $CampaignData->end_after == 'date'): ?>
                        <div class="slider-item">
                        <a href="<?php echo e(route('front.campaign.show',$CampaignData->slug)); ?>" class="item">
                            <div class="single-causes">
                                <div class="img">
                                    <img src="<?php echo e(asset('assets/images/campaign/'.$CampaignData->photo)); ?>" alt="">
                                </div>
                                <div class="content">
                                    <span data-href="<?php echo e(route('front.campaign.donet',$CampaignData->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                    <h4 class="title">
                                        <?php echo e($CampaignData->campaign_name); ?>

                                    </h4>
                                    <p class="text">
                                        <?php echo e(substr(strip_tags($CampaignData->description),0,100)); ?>

                                    </p>

                                        <div class="progress-area">
                                            <div class="persentage">
                                                <span><?php echo e(round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2) > 100.00  ? '100' : round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2)); ?>%</span>
                                            </div>
                                            <div class="progress">
                                                <div class="progress-bar  p-1" style="width:<?php echo e(($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                            </div>
                                        </div>
                                        <div class="top-meta mt-3">
                                            <div class="left">
                                                    <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                            </div>
                                            <div class="right">
                                                <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->goal * $currencies->value ,2)); ?> </span>
                                            </div>
                                        </div>


                                </div>
                            </div>
                        </a>
                        </div>
                        <?php elseif($CampaignData->goal > $CampaignData->available_fund && $CampaignData->end_after == 'goal'): ?>
                        <div class="slider-item">
                            <a href="<?php echo e(route('front.campaign.show',$CampaignData->slug)); ?>" class="item">
                                <div class="single-causes">
                                    <div class="img">
                                        <img src="<?php echo e(asset('assets/images/campaign/'.$CampaignData->photo)); ?>" alt="">
                                    </div>
                                    <div class="content">
                                        <span data-href="<?php echo e(route('front.campaign.donet',$CampaignData->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                        <h4 class="title">
                                            <?php echo e($CampaignData->campaign_name); ?>

                                        </h4>
                                        <p class="text">
                                            <?php echo e(substr(strip_tags($CampaignData->description),0,100)); ?>

                                        </p>

                                            <div class="progress-area">
                                                <div class="persentage">
                                                    <span><?php echo e(round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2) > 100.00  ? '100' : round($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100, 2)); ?>%</span>
                                                </div>
                                                <div class="progress">
                                                    <div class="progress-bar  p-1" style="width:<?php echo e(($CampaignData->donation->sum('donation_amount') / $CampaignData->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="top-meta mt-3">
                                                <div class="left">
                                                        <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                                </div>
                                                <div class="right">
                                                    <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($CampaignData->goal * $currencies->value ,2)); ?> </span>
                                                </div>
                                            </div>


                                    </div>
                                </div>
                            </a>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Causes Area End -->
<?php endif; ?>


<?php if($ps->ccallback==1): ?>
	<!-- Request Area Start -->
<section class="request-to-call">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="section-heading">
					<div class="sub-title">
						<?php echo e($pagesettings->callback_subtitle); ?>

					</div>
					<h2 class="section-title">
						<?php echo e($pagesettings->callback_title); ?>

					</h2>
				</div>
				<div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
				<form action="<?php echo e(route('front.callback.store')); ?>" class="request-form" id="CallbackFrom" method="POST">
					<?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

					<div class="row">
						<div class="col-lg-12">
						<input type="text" placeholder='<?php echo e(__('Enter Your Full Name')); ?>' name="name" value="<?php echo e(Request::old('name')); ?>">
						</div>
					</div>
					<?php echo csrf_field(); ?>
					<div class="row">
						<div class="col-lg-6">
						<input type="text" placeholder="<?php echo e(__('Phone Number')); ?>" name="phone" id="phone" value="<?php echo e(Request::old('phone')); ?>">
						</div>
						<div class="col-lg-6">
							<input type="text" placeholder="<?php echo e(__('Enter Your Email Address')); ?>" id="email" name="email" <?php echo e(Request::old('email')); ?>>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<textarea name="message" id="message" class="input-field textarea" <?php echo e(Request::old('message')); ?> placeholder="<?php echo e(__('What kind of help you need')); ?>"></textarea>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-12">
							<button type="submit" class="mybtn1 submit-btn"><?php echo e(__('Send To Us')); ?> </button>
						</div>
					</div>
				</form>
			</div>
			<div class="col-lg-6">
				<div class="right-area">
					<img src="<?php echo e($pagesettings->callback_image1 ? asset('assets/images/'.$pagesettings->callback_image1):asset('assets/images/noimage.png')); ?>" alt="">
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Request Area End -->
<?php endif; ?>

<?php if($ps->cteam == 1): ?>
	<!-- Team Area Start -->
<section class="team">
	<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-6">
					<div class="section-heading text-center">
						<div class="sub-title">
							<?php echo $pagesettings->team_subtitle; ?>

						</div>
						<h2 class="section-title">
							<?php echo $pagesettings->team_title; ?>

						</h2>
					</div>
				</div>
			</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="team-slider">
					<?php $__currentLoopData = $memberData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="team-member">
						<div class="bg-color">
							<div class="t-img">
									<img src="<?php echo e(asset('assets/images/member/'.$member->photo)); ?>" alt="">

							</div>
                            <div class="content">
                                <p class="name">
                                    <span><?php echo e($member->title); ?></span>

                                    <small><?php echo e($member->subtitle); ?></small>

                                </p>
                                <ul class="social-links">
                                    <li>
                                        <a href="<?php echo e($member->facebook); ?>">
                                            <i class="fab fa-facebook-f"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e($member->twitter); ?>">
                                            <i class="fab fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e($member->linkedin); ?>">
                                            <i class="fab fa-linkedin-in"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>

						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Team Area End -->
<?php endif; ?>

<?php if($ps->cportfolio ==1): ?>
	<!-- Testimonial Area Start -->
<section class="testimonial">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="section-heading text-center">
					<div class="sub-title">
						<?php echo $pagesettings->portfolio_subtitle; ?>

					</div>
					<h2 class="section-title">
							<?php echo $pagesettings->portfolio_title; ?>

					</h2>
				</div>
			</div>
		</div>
		<div class="row justify-content-center">
			<div class="col-lg-12">
				<div class="testimonial-slider">
					<?php $__currentLoopData = $protfolioData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $protfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="slider-item">
                        <a href="<?php echo e(route('front.project',$protfolio->title)); ?>" class="single-testimonial">
                            <div class="people">
                                <div class="img">
                                        <img src="<?php echo e(asset('assets/images/portfolio/'.$protfolio->photo)); ?>" alt="">
                                </div>
                            </div>
                            <div class="review-text">
                                <p>
                                    <?php echo e($protfolio->details); ?>

                                </p>
                            </div>
                            <div class="people">
                                <h4 class="title"><?php echo e($protfolio->title); ?></h4>
                                <p class="designation"><?php echo e($protfolio->subtitle); ?></p>
                            </div>

                        </a>
                    </div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Testimonial Area End -->
<?php endif; ?>

<?php if($ps->cdonate ==1): ?>
	<!-- Donate Area Start -->
	<div class="donate">
		<div class="overlay"></div>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="content">
							<div>
                                <h4 class="title">
                                    <?php echo e($pagesettings->donate_title); ?>

                                </h4>

                                <p class="text-white"><?php echo e($pagesettings->donate_subtitle); ?></p>
                            </div>
							<div class="donet-btn-area">
									<a href="<?php echo e($pagesettings->donate_link1); ?>" class="mybtn1"><?php echo e($pagesettings->donate_button_text); ?></a>
							</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- Donate Area End -->
<?php endif; ?>

<?php if($ps->cnews == 1): ?>
	<!-- Blog Area Start -->
<section class="blog">
	<div class="container-fluid">
			<div class="row justify-content-center">
				<div class="col-lg-6">
					<div class="section-heading text-center">
						<div class="sub-title">
							<?php echo $pagesettings->blog_subtitle; ?>

						</div>
						<h2 class="section-title">
							<?php echo $pagesettings->blog_title; ?>

						</h2>
					</div>
				</div>
			</div>
		<div class="row">
			<div class="col-lg-12">
				<div class="blog-slider">
					<?php $__currentLoopData = $blogData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="single-blog">
						<div class="img">
							<img src="<?php echo e($blog->photo ? asset('assets/images/blogs/'.$blog->photo):asset('assets/images/noimage.png')); ?>" alt="">
						</div>
						<div class="content">
                            <div class="inner-content">
                              <div class="i-i-c">
                                    <a href="<?php echo e(route('front.blog.show',$blog->slug)); ?>">
                                        <h4 class="blog-title">
                                            <?php echo e(strlen($blog->title) > 200 ? substr($blog->title,0,200)."...":$blog->title); ?>

                                            </h4>
                                    </a>
                                    <div class="text">
                                        <p>
                                            <?php echo e(substr(strip_tags($blog->details),0,100)); ?>

                                        </p>
                                    </div>
                              </div>
                            </div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
		</div>
	</div>
</section>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/work/charity_7/project/resources/views/front/index.blade.php ENDPATH**/ ?>