
<?php echo $email_body; ?><?php /**PATH /home/muktooxy/public_html/project/resources/views/admin/email/mailbody.blade.php ENDPATH**/ ?>