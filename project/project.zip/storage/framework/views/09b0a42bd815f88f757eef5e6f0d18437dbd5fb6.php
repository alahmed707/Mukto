<?php echo $__env->yieldContent('styles'); ?>

<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('assets/admin/js/load.js')); ?>"></script>
	
<?php echo $__env->yieldContent('scripts'); ?>
<?php /**PATH /home/devgenius/public_html/charity/project/resources/views/layouts/load.blade.php ENDPATH**/ ?>