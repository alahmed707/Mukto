

<?php $__env->startSection('content'); ?>

<div class="content-area">
              <div class="mr-breadcrumb">
                <div class="row">
                  <div class="col-lg-12">
                      <h4 class="heading"><?php echo e(__('Home Page Customization')); ?></h4>
                    <ul class="links">
                      <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                      </li>
                      <li>
                        <a href="javascript:;"><?php echo e(__('Home Page Settings')); ?></a>
                      </li>
                      <li>
                        <a href="<?php echo e(route('admin-ps-customize')); ?>"><?php echo e(__('Home Page Customization')); ?></a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="add-product-content">
                <div class="row">
                  <div class="col-lg-12">
                    <div class="product-description">
                      <div class="social-links-area">
                        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->admin_loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>

                        <form id="geniusform" action="<?php echo e(route('admin-ps-homeupdate')); ?>" method="POST" enctype="multipart/form-data">
                          <?php echo e(csrf_field()); ?>


                        <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>  

                <div class="row justify-content-center">
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="cservice"><?php echo e(__('Service Section')); ?></label>
                    <label class="switch float-right">
                      <input type="checkbox" name="cservice" value="1" <?php echo e($data->cservice==1?"checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
                  <div class="col-lg-2"></div>
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="ccounter"><?php echo e(__('Counter Section')); ?></label>
                    <label class="switch float-right">
                      <input type="checkbox" name="ccounter" value="1" <?php echo e($data->ccounter==1?"checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>

                <div class="row justify-content-center">
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="best"><?php echo e(__('Feature Section')); ?></label>
                    <label class="switch float-right">
                      <input type="checkbox" name="cfeature" value="1" <?php echo e($data->cfeature==1?"checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
                  <div class="col-lg-2"></div>
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="contact_section"><?php echo e(__('Donate Section')); ?></label>
                    <label class="switch float-right">
                      <input type="checkbox" name="cdonate" value="1" <?php echo e($data->cdonate == 1 ? "checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
              </div>

                <div class="row justify-content-center">
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="pricing_plan"><?php echo e(__('Request Call-Back Section')); ?></label>
                    <label class="switch float-right">
                      <input type="checkbox" name="ccallback" value="1" <?php echo e($data->ccallback == 1 ? "checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>

                  <div class="col-lg-2"></div>

                  <div class="col-lg-4 d-flex justify-content-between">
                    <label class="control-label" for="big"><?php echo e(__('Team Section')); ?></label>
                        <label class="switch float-right">
                          <input type="checkbox" name="cteam" value="1" <?php echo e($data->cteam==1?"checked":""); ?>>
                          <span class="slider round"></span>
                      </label>
                  </div>
                </div>

                <div class="row justify-content-center">
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="hot_sale"><?php echo e(__('Portfolio section')); ?></label>
                    <label class="switch float-right">
                      <input type="checkbox" name="cportfolio" value="1" <?php echo e($data->cportfolio==1?"checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
                  <div class="col-lg-2"></div>
                  <div class="col-lg-4 d-flex justify-content-between">
                  <label class="control-label" for="review_blog"><?php echo e(__('Latest Blog/News Section')); ?> </label>
                    <label class="switch float-right">
                      <input type="checkbox" name="cnews" value="1" <?php echo e($data->cnews==1?"checked":""); ?>>
                      <span class="slider round"></span>
                    </label>
                  </div>
                </div>

                <br>

                <div class="row">
                  <div class="col-12 text-center">
                    <button type="submit" class="submit-btn"><?php echo e(__('Submit')); ?></button>
                  </div>
                </div>

                     </form>

                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgenius/public_html/charity/project/resources/views/admin/pagesetting/customize.blade.php ENDPATH**/ ?>