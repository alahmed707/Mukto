

<?php $__env->startSection('content'); ?>

        <div class="col-lg-9">

          <div class="transaction-area">
            <div class="heading-area">
              <h3 class="title">
               <?php echo e(__('My Withdraws')); ?>

               <?php if(Auth::user()->campaign->where('is_panding',1)->where('status','open')->count() > 0): ?>
               <a href="<?php echo e(route('user-wwt-create')); ?>" class="btn btn-primary btn-round ml-2"><?php echo e(__('Withdraw Now')); ?></a>
               <?php endif; ?>
              </h3>
            </div>
            <div class="content">

							<div class="mr-table allproduct mt-4">
									<div class="table-responsiv">
											<table id="example" class="table table-hover dt-responsive" cellspacing="0" width="100%">
												<thead>
													<tr>
														<th><?php echo e(__('Withdraw Date')); ?></th>
														<th><?php echo e(__('Method')); ?></th>
														<th><?php echo e(__('Account')); ?></th>
														<th><?php echo e(__('Amount')); ?></th>
														<th><?php echo e(__('Status')); ?></th>
													</tr>
												</thead>
												<tbody>
                            <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(date('d-M-Y',strtotime($withdraw->created_at))); ?></td>
                                    <td><?php echo e($withdraw->method); ?></td>
                                    <?php if($withdraw->method != "Bank"): ?>
                                        <td><?php echo e($withdraw->acc_email); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($withdraw->iban); ?></td>
                                    <?php endif; ?>
                                    <?php if($gs->currency_format == 0): ?>
                                        <td><?php echo e($currencies->sign); ?> <?php echo e(round($withdraw->amount * $currencies->value, 2)); ?></td>
                                    <?php else: ?>  
                                        <td><?php echo e(round($withdraw->amount, 2)); ?></td>
                                    <?php endif; ?>
                                    
                                    <td><?php echo e(ucfirst($withdraw->status)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</tbody>
											</table>
									</div>
								</div>
            </div>
          </div>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
	   $('#example').DataTable({
               ordering: false
            });
</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/user/withdraw/index.blade.php ENDPATH**/ ?>