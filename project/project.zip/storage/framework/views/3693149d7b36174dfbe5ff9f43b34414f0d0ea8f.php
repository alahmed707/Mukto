<?php $__env->startSection('content'); ?>

<!-- Breadcrumb Area Start -->
<?php if($gs->breadcumb_banner): ?>
<div class="breadcrumb-area" style="background: url(<?php echo e(asset('assets/images/'.$gs->breadcumb_banner)); ?>);">
    <div class="overlay"></div>
<?php else: ?>
<div class="breadcrumb-area">
    <div class="overlay"></div>
<?php endif; ?>
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
        <h1 class="pagetitle">
          <?php echo e(__('Blog')); ?>

        </h1>
        <ul class="pages">
          <li>
            <a href="<?php echo e(route('front.index')); ?>">
              <?php echo e(__('Home')); ?>

            </a>
          </li>
          <li class="active">
            <a href="<?php echo e(route('front.blog')); ?>">
               <?php echo e(__('Blog')); ?>

            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</div>
<!-- Breadcrumb Area End -->
<!-- Blog Area Start -->
<section class="blog-page">
  <div class="container">
      <div class="row">
          <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-lg-6 col-md-6">
            <div class="single-blog">
                <div class="img">
                    <img src="<?php echo e($blog->photo ? asset('assets/images/blogs/'.$blog->photo):asset('assets/images/noimage.png')); ?>" alt="">
                </div>
                <div class="content">
                    <div class="inner-content">
                      <div class="i-i-c">
                            <a href="<?php echo e(route('front.blog.show',$blog->slug)); ?>">
                                <h4 class="blog-title">
                                    <?php echo e(strlen($blog->title) > 200 ? substr($blog->title,0,200)."...":$blog->title); ?>

                                    </h4>
                            </a>
                            <div class="text">
                                <p>
                                    <?php echo e(substr(strip_tags($blog->details),0,70)); ?>

                                </p>
                            </div>
                      </div>
                    </div>
                </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="page-center">
              <h3 class="text-center"> <?php echo e(__('No Post Found')); ?></h3>
          </div>
          <?php endif; ?>
      </div>

      <div class="page-center">
          <?php if(isset($_GET['search'])): ?>
            <?php echo e($blogs->appends(['search' => $_GET['search']])->links()); ?>

          <?php else: ?>
            <?php echo e($blogs->links()); ?>

          <?php endif; ?>
      </div>
  </div>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\project\resources\views/front/blog.blade.php ENDPATH**/ ?>