<?php $__env->startSection('content'); ?>


  <!-- Breadcrumb Area Start -->
  <?php if($gs->breadcumb_banner): ?>
  <div class="breadcrumb-area" style="background: url(<?php echo e(asset('assets/images/'.$gs->breadcumb_banner)); ?>);">
    <div class="overlay"></div>
  <?php else: ?>
  <div class="breadcrumb-area">
    <div class="overlay"></div>
  <?php endif; ?>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <h1 class="pagetitle">
            <?php echo e($page->title); ?>

          </h1>
          <ul class="pages">
              <li>
                <a href="<?php echo e(route('front.index')); ?>">
                  <?php echo e(__('Home')); ?>

                </a>
              </li>
              <li class="active">
                <a href="<?php echo e(route('front.page',$page->slug)); ?>">
                  <?php echo e($page->title); ?>

                </a>
              </li>

          </ul>
        </div>
      </div>
    </div>
  </div>
  <!-- Breadcrumb Area End -->

<section class="about">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="about-info">
            <p>
							<?php echo $page->details; ?>

            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\charity\project\resources\views/front/page.blade.php ENDPATH**/ ?>