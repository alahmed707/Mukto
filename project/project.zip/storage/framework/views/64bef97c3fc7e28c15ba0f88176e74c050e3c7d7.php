

<?php $__env->startSection('styles'); ?>

<style type="text/css">
    .table-responsive {
    overflow-x: hidden;
}
table#example2 {
    margin-left: 10px;
}

</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-area">
    <div class="mr-breadcrumb">
        <div class="row">
            <div class="col-lg-12">
                <h4 class="heading"><?php echo e(__('Customer Details')); ?> <a class="add-btn" href="javascript:history.back();"><i class="fas fa-arrow-left"></i><?php echo e(__('Back')); ?></a></h4>
                <ul class="links">
                    <li>
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin-user-index')); ?>"><?php echo e(__('Customers')); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin-user-show',$data->id)); ?>"><?php echo e(__('Details')); ?></a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="add-product-content customar-details-area">
        <div class="row">
            <div class="col-lg-12">
                <div class="product-description">
                    <div class="body-area">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="user-image">
                                    <?php if($data->is_provider == 1): ?>
                                    <img src="<?php echo e($data->photo ? asset($data->photo):asset('assets/images/noimage.png')); ?>" alt="No Image"> <?php else: ?>
                                    <img src="<?php echo e($data->photo ? asset('assets/images/users/'.$data->photo):asset('assets/images/noimage.png')); ?>" alt="No Image"> <?php endif; ?>
                                    <a href="javascript:;" class="mybtn1 send" data-email="<?php echo e($data->email); ?>" data-toggle="modal" data-target="#vendorform"><?php echo e(__('Send Message')); ?></a>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="table-responsive show-table">
                                    <table class="table">
                                        <tr>
                                            <th>ID#</th>
                                            <td><?php echo e($data->id); ?></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <td><?php echo e($data->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Email')); ?></th>
                                            <td><?php echo e($data->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Phone')); ?></th>
                                            <td><?php echo e($data->phone); ?></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo e(__('Address')); ?></th>
                                            <td><?php echo e($data->address); ?></td>
                                        </tr>

                                    </table>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="table-responsive show-table">
                                    <table class="table">

                                        <?php if($data->city != null): ?>
                                        <tr>
                                            <th><?php echo e(__('City')); ?></th>
                                            <td><?php echo e($data->city); ?></td>
                                        </tr>
                                        <?php endif; ?> <?php if($data->fax != null): ?>
                                        <tr>
                                            <th><?php echo e(__('Fax')); ?></th>
                                            <td><?php echo e($data->fax); ?></td>
                                        </tr>
                                        <?php endif; ?> <?php if($data->zip != null): ?>
                                        <tr>
                                            <th><?php echo e(__('Zip Code')); ?></th>
                                            <td><?php echo e($data->zip); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <th><?php echo e(__('Joined')); ?></th>
                                            <td><?php echo e($data->created_at->diffForHumans()); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="order-table-wrap">
                        <div class="order-details-table">
                            <div class="mr-table">
                                <h4 class="title"><?php echo e(__('Campaign List')); ?></h4>
                                <div class="table-responsive">
                                    <table id="example2" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th><?php echo e(__('Name')); ?></th>
                                                <th><?php echo e(__('Category')); ?></th>
                                                <th><?php echo e(__('Goal')); ?></th>
                                                <th><?php echo e(__('End Date')); ?></th>
                                                <th colspan="3"><?php echo e(__('Status')); ?></th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                            $Currency = App\Models\Currency::where('is_default',1)->first();
                                        ?>
                                            <?php $__currentLoopData = $data->campaign; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <?php if($campaign->status=='open' && $campaign->is_panding == 1): ?>
                                                    <a href="<?php echo e(route('admin-campaign-view',$campaign->id)); ?>"><?php echo e($campaign->campaign_name); ?></a> <?php else: ?>
                                                    <a href="<?php echo e(route('admin-campaign-panding-view',$campaign->id)); ?>"><?php echo e($campaign->campaign_name); ?></a> <?php endif; ?>
                                                </td>
                                                <td><?php echo e($campaign->category->name); ?></td>

                                                <td> <?php echo e($Currency->sign); ?>  <?php echo e(round($campaign->goal * $Currency->value ,2)); ?></td>
                                                <td><?php echo e(date('Y-m-d h:i:s a',strtotime($campaign->end_date))); ?></td>
                                                <td>

                                                    <?php if($campaign->status=='open' || $campaign->is_panding == 1): ?> <?php if($campaign->status=='open' && $campaign->is_panding == 1): ?>
                                                    <span class="text-white badge badge-success p-2"><?php echo e(__('Open')); ?></span> <?php else: ?>
                                                    <span class="text-white badge badge-info p-2"><?php echo e(__('Panding')); ?></span> <?php endif; ?> <?php else: ?>
                                                    <span class="text-white badge badge-danger p-2"><?php echo e(__('Close')); ?></span> <?php endif; ?>
                                                </td>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="sub-categori">
    <div class="modal" id="vendorform" tabindex="-1" role="dialog" aria-labelledby="vendorformLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="vendorformLabel">Send Message</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid p-0">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="contact-form">
                                    <form id="emailreply1">
                                        <?php echo e(csrf_field()); ?>

                                        <ul>
                                            <li>
                                                <input type="email" class="input-field eml-val" id="eml1" name="to" placeholder="Email *" value="" required="">
                                            </li>
                                            <li>
                                                <input type="text" class="input-field" id="subj1" name="subject" placeholder="Subject *" required="">
                                            </li>
                                            <li>
                                                <textarea class="input-field textarea" name="message" id="msg1" placeholder="Your Message *" required=""></textarea>
                                            </li>
                                        </ul>
                                        <button class="submit-btn" id="emlsub1" type="submit">Send Message</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
                    


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
$('#example2').dataTable( {
  "ordering": false,
      'paging'      : false,
      'lengthChange': false,
      'searching'   : false,
      'ordering'    : false,
      'info'        : false,
      'autoWidth'   : false,
      'responsive'  : true
} );
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgenius/public_html/charity/project/resources/views/admin/user/show.blade.php ENDPATH**/ ?>