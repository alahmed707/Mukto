
<?php $__env->startSection('styles'); ?>

 <?php $__env->startSection('content'); ?>
 
 <div class="col-lg-9 add_lan_tab">
     
        <nav>
            <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true"><?php echo e(__('Campaign Details')); ?></a>
                <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false"><?php echo e(__('Donations')); ?></a>
            </div>
        </nav>
        <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
            
            <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="product-description">
                            <div class="body-area">
                                <div class="table-responsive">
                                    <table class="table">
                                        <tbody>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Campaign Name')); ?>:</th>
                                                <td><?php echo e($data->campaign_name); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Category')); ?>:</th>
                                                <td><?php echo e($data->category->name); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Slug')); ?>:</th>
                                                <td><?php echo e($data->category->slug); ?></td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Photo')); ?>:</th>
                                                <td><img class="campaign-photo" src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt=""></td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Goal')); ?>:</th>
                                                <td><span><?php echo e($currencies->sign); ?> <?php echo e(round($data->goal * $currencies->value , 2 )); ?></span></td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Video Link')); ?>:</th>
                                                <td><span> <?php echo e($data->video_link); ?></span></td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Details')); ?>:</th>
                                                <td>
                                                    <p class="text-justify"><?php echo $data->description; ?></p>
                                                </td>
                                            </tr>
                                            <?php if($data->preloaded_amount): ?>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Preloaded amount')); ?> (<?php echo e($currencies->name); ?>):</th>
                                                <td>
                                                    
                                                    <?php $__currentLoopData = explode(',',$data->preloaded_amount); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="mr-3"><?php echo e(round($item*$currencies->value ,2)); ?></span>
                                                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Tags')); ?>:</th>
                                                <td>
                                                    <?php $__currentLoopData = explode(',',$data->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="mr-3"><?php echo e($item); ?></span> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Featured Allow')); ?>:</th>
                                                <td>
                                                    <?php if($data->featured==1): ?>
                                                    <span class="text-success"> Active </span> <?php else: ?>
                                                    <span class="text-danger">Deactivate</span> <?php endif; ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Ending Date')); ?>:</th>
                                                <td>
                                                    <?php echo e($data->end_date); ?>

                                                </td>
                                            </tr>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Status')); ?>:</th>
                                                <td>
                                                    <?php if($data->status=='open' || $data->is_panding == 1): ?> 
                                                        <?php if($data->status=='open' && $data->is_panding == 1): ?>
                                                            <span class="text-success">Open</span>
                                                        <?php else: ?>
                                                            <span class="text-info">Panding</span>
                                                         <?php endif; ?>
                                                     <?php else: ?>
                                                        <span class="text-danger">Close</span>
                                                     <?php endif; ?>
                                                </td>
                                            </tr>
                                            <?php if($data->benefits): ?>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Benefits')); ?>:</th>
                                                <td>
                                                    <?php echo e($data->benefits); ?>

                                                </td>
                                            </tr>
                                            <?php endif; ?> 
                                            <?php if($data->location): ?>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Location')); ?>:</th>
                                                <td>
                                                    <?php echo e($data->location); ?>

                                                </td>
                                            </tr>
                                            <?php endif; ?> 
                                            <?php if($data->meta_tag): ?>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Meta Tag')); ?>:</th>
                                                <td>
                                                    <?php $__currentLoopData = explode(',' , $data->meta_tag); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($meta_tag); ?>

                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            </tr>
                                            <?php endif; ?> 
                                            <?php if($data->meta_description): ?>
                                            <tr>
                                                <th class="auction-details-heading"><?php echo e(__('Meta Description')); ?>:</th>
                                                <td>
                                                    <?php echo e($data->meta_description); ?>

                                                </td>
                                            </tr>
                                            <?php endif; ?> 
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="mr-table allproduct">
                            <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <div class="table-responsiv">
                                <table id="bid-table" class="table table-hover dt-responsive table-bordered" cellspacing="0" width="100%">
                                    <thead>
                                        <tr>
                                            <th><?php echo e(__('Name')); ?></th>
                                            <th><?php echo e(__('Email')); ?></th>
                                            <th><?php echo e(__('Phone')); ?></th>
                                            <th><?php echo e(__('Address')); ?></th>
                                            <th><?php echo e(__('Amount')); ?></th>
                                            <th><?php echo e(__('Note')); ?></th>
                                            <th><?php echo e(__('Date')); ?></th>
                                        </tr>
                                        <tbody>
                                            <?php $__currentLoopData = $data->donation()->orderBy('id','desc')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($donation->fname); ?> <?php echo e(' '. $donation->lname); ?></td>
                                                <td><?php echo e($donation->email); ?></td>
                                                <td><?php echo e($donation->number); ?></td>
                                                <td><?php echo e($donation->address); ?></td>
                                                <td><?php echo e($currencies->sign); ?> <?php echo e(round($donation->donation_amount * $currencies->value ,2)); ?></td>
                                                <td>
                                                    <?php if($donation->note): ?> <?php echo e($donation->note); ?> <?php else: ?> No Note <?php endif; ?>
                                                </td>
                                                <td><?php echo e($donation->created_at->format('Y-m-d')); ?></td>

                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
    $('#example').DataTable();
    
    $('.deleteData').click(function(){
        var location = $(this).attr('data-href');
        console.log(location);
         $(".deleteButton").attr("href", location);
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/user/campaign/view.blade.php ENDPATH**/ ?>