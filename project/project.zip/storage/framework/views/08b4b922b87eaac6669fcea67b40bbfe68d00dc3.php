
 
<?php $__env->startSection('content'); ?>
    <div class="content-area">
        <div class="mr-breadcrumb">
            <div class="row">
                <div class="col-lg-12">
                    <h4 class="heading"><?php echo e(__('View Campaign')); ?><a class="add-btn" href="<?php echo e(url()->previous()); ?>"><i class="fas fa-arrow-left"></i> Back</a></h4>
                    <ul class="links">
                        <li>
                            <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('Dashboard')); ?> </a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin-campaign-index')); ?>"><?php echo e(__('Campaign')); ?></a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('admin-campaign-view',$data->id)); ?>"><?php echo e(__('View Campaign')); ?></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="row add_lan_tab justify-content-center bg-white">
            <div class="col-lg-10">
                <nav class="m-3">
                    <div class="nav nav-tabs nav-fill" id="nav-tab" role="tablist">
                        <a class="nav-item nav-link active" id="nav-home-tab" data-toggle="tab" href="#nav-home" role="tab" aria-controls="nav-home" aria-selected="true"><?php echo e(__('Campaign Details')); ?></a>
                        <a class="nav-item nav-link" id="nav-profile-tab" data-toggle="tab" href="#nav-profile" role="tab" aria-controls="nav-profile" aria-selected="false"><?php echo e(__('Donations')); ?></a>
                        <a class="nav-item nav-link" id="nav-withdrow-tab" data-toggle="tab" href="#nav-withdrow" role="tab" aria-controls="nav-withdrow" aria-selected="false"><?php echo e(__('Withdraw')); ?></a>
                    </div>
                </nav>
                <div class="tab-content py-3 px-3 px-sm-0" id="nav-tabContent">
                    
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="product-description">
                                    <div class="body-area">
                                        <p class="text-center ShowFund text-success"></p>
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tbody>
                                                    <?php
                                                        $Currency = App\Models\Currency::where('is_default',1)->first();
                                                    ?>
                                                     <?php if($data->user_id > 0): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('User Name')); ?>:</th>
                                                        <td>
                                                        <a href="<?php echo e(route('admin-user-show',$data->user->id)); ?>"><span><?php echo e($data->user->name); ?></span></a>
                                                        </td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Campaign Name')); ?>:</th>
                                                        <td><?php echo e($data->campaign_name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Category')); ?>:</th>
                                                        <td><?php echo e($data->category->name); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Slug')); ?>:</th>
                                                        <td><?php echo e($data->category->slug); ?></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Photo')); ?>:</th>
                                                        <td>
                                                            <img  src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Goal')); ?> <small> (<?php echo e($Currency->name); ?>) </small> :</th>
                                                        <td><span><?php echo e($Currency->sign); ?> <?php echo e(round( $data->goal * $Currency->value ,2)); ?></span></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Video Link')); ?>:</th>
                                                        <td><span> <?php echo e($data->video_link); ?></span></td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Details')); ?>:</th>
                                                        <td>
                                                            <p><?php echo $data->description; ?></p>
                                                        </td>
                                                    </tr>
                                                    <?php if($data->preloaded_amount): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Preloaded amount')); ?> <small> (<?php echo e($Currency->name); ?>) </small>:</th>
                                                            <td>
                                                                <?php $__currentLoopData = explode(',', $data->preloaded_amount); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <span class="mr-3"><?php echo e(round($item * $Currency->value ,2)); ?></span>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                        </tr>  
                                                    <?php endif; ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Tags')); ?>:</th>
                                                        <td>
                                                            <?php $__currentLoopData = explode(',',$data->tags); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span class="mr-3"><?php echo e($item); ?></span>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Featured Allow')); ?>:</th>
                                                        <td>
                                                            <?php if($data->featured==1): ?>
                                                                <span class="text-success"> <?php echo e(__('Actived')); ?> </span>
                                                             <?php else: ?>
                                                                <span class="text-danger"><?php echo e(__('Deactivated')); ?></span>
                                                             <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Closing Status')); ?>:</th>
                                                        <td>
                                                            <?php echo e($data->end_after); ?>

                                                        </td>
                                                    </tr>

                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Ending Date')); ?>:</th>
                                                        <td>
                                                            <?php echo e($data->end_date); ?>

                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Status')); ?>:</th>
                                                        <td>
                                                            <?php if($data->status=='open' || $data->is_panding == 1): ?> 
                                                                <?php if($data->status=='open' && $data->is_panding == 1): ?>
                                                                    <span class="text-success"><?php echo e(__('Open')); ?></span>
                                                                <?php else: ?>
                                                                    <span class="text-info"><?php echo e(__('Panding')); ?></span>
                                                                 <?php endif; ?>
                                                             <?php else: ?>
                                                                <span class="text-danger">Close</span>
                                                             <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <?php if($data->benefits): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Benefits')); ?>:</th>
                                                        <td>
                                                            <?php echo e($data->benefits); ?>

                                                        </td>
                                                    </tr>
                                                    <?php endif; ?>
                                                     <?php if($data->location): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Location')); ?>:</th>
                                                        <td>
                                                            <?php echo e($data->location); ?>

                                                        </td>
                                                    </tr>
                                                    <?php endif; ?>
                                                    <?php if($data->meta_tag): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Meta Tags')); ?>:</th>
                                                        <td>
                                                            <?php $__currentLoopData = explode(',' , $data->meta_tag); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta_tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php echo e($meta_tag); ?>

                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </td>
                                                    </tr>
                                                    <?php endif; ?> 
                                                    <?php if($data->meta_description): ?>
                                                    <tr>
                                                        <th class="auction-details-heading"><?php echo e(__('Meta Description')); ?>:</th>
                                                        <td>
                                                            <?php echo e($data->meta_description); ?>

                                                        </td>
                                                    </tr>
                                                    <?php endif; ?> 
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mr-table allproduct">
                                    <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <div class="table-responsiv">
                                        <p class="text-center ShowFund text-success"></p>
                                        <table id="geniustableDonation" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th><?php echo e(__('Name')); ?></th>
                                                    <th><?php echo e(__('Email')); ?></th>
                                                    <th><?php echo e(__('Phone')); ?></th>
                                                    <th><?php echo e(__('Address')); ?></th>
                                                    <th><?php echo e(__('Amount')); ?></th>
                                                    <th><?php echo e(__('Note')); ?></th>
                                                    <th><?php echo e(__('Date')); ?></th>
                                                </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tab-pane fade mb-3" id="nav-withdrow" role="tabpanel" aria-labelledby="nav-withdrow-tab">
                        <div class="content-area">
                            <div class="product-area">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="mr-table allproduct">
                                            <?php echo $__env->make('includes.admin.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <div class="table-responsiv">
                                                <p class="text-center ShowFund text-success"></p>
                                                <a class="add-btn float-right" href="<?php echo e(route('admin-campaign-withdrow-create',$data->id)); ?>" >
                                                    <i class="fas fa-plus"></i> <?php echo e(__('New Withdraw')); ?>

                                                </a>
                                                 
                                                <table id="geniustable" class="table table-hover dt-responsive" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                            <th width="20%"><?php echo e(__('Method')); ?></th>
                                                        <th width="10%"><?php echo e(__('Account')); ?></th>
                                                            <th width="10%"><?php echo e(__('Amount')); ?>  <small> (<?php echo e($Currency->name); ?>)</small></th>
                                                            <th width="10%"><?php echo e(__('Status')); ?></th>
                                                            <th width="20%"><?php echo e(__('Date')); ?></th>
                                                        </tr>
                                                    </thead>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<input type="hidden" id="campaign_id" value="<?php echo e($data->id); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>





<script type="text/javascript">

    var table = $('#geniustable').DataTable({
           ordering: false,
           processing: true,
           serverSide: true,
           ajax: '<?php echo e(route('admin-campaign-withdrow-datatables')); ?>',
           columns: [
                    { data: 'method', name: 'method' },
                    { data: 'acc_email', name: 'acc_email' },
                    { data: 'amount', name: 'amount' },
                    { data: 'created_at', searchable: false, orderable: false},
                    { data: 'status', name: 'status' },
                 ],
           
            
        });


    var table = $('#geniustableDonation').DataTable({
           ordering: false,
           processing: true,
           serverSide: true,
           ajax: '<?php echo e(route('admin-donation-datatables-single', $data->id)); ?>',
           columns: [
                    { data: 'name', name: 'name' },
                    { data: 'email', name: 'email' },
                    { data: 'number', name: 'number' },
                    { data: 'address', name: 'address' },
                    { data: 'donation_amount', name: 'donation_amount' },
                    { data: 'note', name: 'note' },
                    { data: 'created_at', searchable: false, orderable: false},
                    
                 ],
           
            
        });




var value = $('#campaign_id').val();
         $.ajax({
             type: "get",
             url: '<?php echo e(url('admin/campaign/availble-fund/get')); ?>/' + value,
             success: function(data)
             {
                 $('.ShowFund').html(data);
             }
             });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/devgenius/public_html/charity/project/resources/views/admin/campaign/view.blade.php ENDPATH**/ ?>