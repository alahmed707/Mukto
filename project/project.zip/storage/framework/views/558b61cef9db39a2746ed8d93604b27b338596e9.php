	<?php if(count($datas) > 0): ?>
		<a id="order-notf-clear" data-href="<?php echo e(route('order-notf-clear')); ?>" class="clear" href="javascript:;">
			<?php echo e(__('Clear All')); ?>

		</a>
		<ul>
	<?php if($datas->count() > 0 ): ?>
		<?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php if($data->donation_id): ?>
		<li>
			<a href="<?php echo e(route('admin-campaign-view',$data->donationShow->campaign_id)); ?>"> <i class="fas fas fa-donate"></i> <?php echo e(__('View New Donation')); ?></a>
		</li>
		<?php elseif($data->campaign_id): ?>
		<li>
			<a href="<?php echo e(route('admin-campaign-panding-index')); ?>"> <i class="fas fa-hand-holding-heart"></i><?php echo e(__('View New Campaign')); ?></a>
		</li>
		<?php elseif($data->withdrow_id): ?>
		<li>
			<a href="<?php echo e(route('admin-withdraw-index')); ?>"> <i class="fas fa-hand-holding-usd"></i> <?php echo e(__('New Withdraw Request')); ?></a>
		</li>
		<?php endif; ?>
			
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>
		</ul>

		<?php else: ?> 

		<a class="clear" href="javascript:;">
			<?php echo e(__('No New Notifications.')); ?>

		</a>

		<?php endif; ?><?php /**PATH /home/muktooxy/public_html/project/resources/views/admin/notification/notification.blade.php ENDPATH**/ ?>