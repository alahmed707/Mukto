
<?php $__env->startSection('content'); ?>

<div class="col-lg-9">
          <div class="transaction-area">

            <div class="heading-area">
              <h3 class="title">
                <?php echo e(__('Campaign Update')); ?>

              </h3>
            </div>
            <?php echo $__env->make('includes.form-success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
              <?php echo $__env->make('includes.form-error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
              <form id="userform" class="px-4" action="<?php echo e(route('user-campaign-update',$data->id)); ?>" enctype="multipart/form-data">
                <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
                    <?php echo e(csrf_field()); ?>

                    <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
                    <div class="row">
                      <div class="col-lg-12">
                            <div class="form-group bmd-form-group">
                                <label for="campaign_name" class="bmd-label-floating"><?php echo e(__('Campaign Name')); ?>*</label>
                                <input type="text" class="form-control" id="campaign_name" name="campaign_name" required="" value="<?php echo e($data->campaign_name); ?>">
                                <span class="bmd-help"><?php echo e(__('Campaign Name')); ?></span>
                            </div>
                      </div>

                      <div class="col-lg-12">
                            <div class="form-group bmd-form-group">
                                <label for="slug" class="bmd-label-floating"><?php echo e(__('Slug')); ?>*</label>
                                <input type="text" class="form-control" id="slug" name="slug" required="" value="<?php echo e($data->slug); ?>">
                                <span class="bmd-help"><?php echo e(__('Slug')); ?></span>
                            </div>
                      </div>

                      <div class="col-lg-12 mb-4">
                        <div class="form-group bmd-form-group">
                          <select name="category_id" id="category_id" class="form-control" required>
                              <option value="" selected disabled><?php echo e(__('Select Category')); ?></option>            
                              <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($item->id); ?>" <?php echo e($data->category_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->name); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
                          </select>
                        </div>
                    </div>

                      <div class="upload-image-area mb-4">
                        <div class="img">
                            <img class="uploadImageBefore" src="<?php echo e($data->photo ? asset('assets/images/campaign/'.$data->photo) : asset('assets/admin/images/upload.png')); ?>">
                            <div>
                              <label  for="photo" class="mybtn1 edit-profile"><?php echo e(__('Upload Image')); ?></label>
                            </div>
                          <input class="d-none upload" id="photo" type="file" name="photo">
                        </div>
                      </div>

                      <div class="col-lg-12">
                            <div class="form-group bmd-form-group">
                                <label for="description" class="bmd-label-floating"><?php echo e(__('Description')); ?>*</label>
                               <textarea name="description" class="form-control" id="description" cols="30" rows="6"><?php echo $data->description; ?></textarea>
                            </div>
                      </div>

                      <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="video_link" class="bmd-label-floating"><?php echo e(__('Campaign Video Link')); ?>*</label>
                            <input type="text" class="form-control" id="video_link" name="video_link" value="<?php echo e($data->video_link); ?>">
                            <span class="bmd-help"><?php echo e(__('Campaign Video Link')); ?></span>
                        </div>
                      </div>

                      <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="end_date" class="bmd-label-floating"><?php echo e(__('End Date')); ?>*</label>
                            <input type="text" class="form-control" id="end_date" name="end_date" required="" value="<?php echo e($data->end_date); ?>">
                            <span class="bmd-help"><?php echo e(__('End Date')); ?></span>
                        </div>
                      </div>

                      <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                        <label for="goal" class="bmd-label-floating"><?php echo e(__('Goal')); ?>* (<?php echo e($currencies->name); ?>)</label>
                            <input type="text" class="form-control" id="goal" name="goal" required="" value="<?php echo e(round($data->goal * $currencies->value ,2)); ?>">
                            <span class="bmd-help"><?php echo e(__('Goal')); ?></span>
                        </div>
                      </div>

                      <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="benefits" class="bmd-label-floating"><?php echo e(__('Benefits')); ?></label>
                            <input type="number" class="form-control" id="benefits" name="benefits"  value="<?php echo e($data->benefits); ?>">
                            <span class="bmd-help"><?php echo e(__('Benefits')); ?></span>
                        </div>
                      </div>

                      <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="location" class="bmd-label-floating"><?php echo e(__('Location')); ?></label>
                            <input type="text" class="form-control" id="location" name="location" value="<?php echo e($data->location); ?>">
                            <span class="bmd-help"><?php echo e(__('Location')); ?></span>
                        </div>
                      </div>

                      

                      <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="preloaded_amount"><?php echo e(__('Preloaded Amount')); ?> <small><?php echo e(__('(Seperated By Comma(,))')); ?></small></label>
                        <input type="text" class="preloaded_amount" value="<?php echo e($data->preloaded_amount); ?>" id="preloaded_amount"  name="preloaded_amount[]">
                        </div>
                      </div>
                     

                      <div class="col-lg-12 mb-4">
                        <div class="form-group bmd-form-group">
                            <label for="tags"><?php echo e(__('Tags')); ?> <small><?php echo e(__('(Seperated By Comma(,))')); ?></small></label>
                        <input type="text" class="tags" placeholder=" " id="tags"  name="tags" value="<?php echo e($data->tags); ?>">
                        </div>
                        <!--<label for="allowProductSEO"><input type="checkbox" <?php echo e(($data->meta_tag != null || strip_tags($data->meta_description) != null) ? 'checked':''); ?> id="allowProductSEO" class="mr-2" name="secheck"> <?php echo e(__('Allow Campaign SEO')); ?></label>-->
                      </div>

                    <div class="col-lg-12 showMetaData <?php echo e($data->meta_tag != null  || strip_tags($data->meta_description != null) ? " ":"d-none"); ?>">
                        <div class="form-group bmd-form-group">
                            <label for="meta_tag"><?php echo e(__('Meta Tag')); ?></label>
                        <input type="text" class="tags" placeholder=" " id="meta_tag"  name="meta_tag" value="<?php echo e($data->meta_tag); ?>">
                        </div>
                      </div>
                      <div class="col-lg-12 showMetaData <?php echo e($data->meta_tag != null  || strip_tags($data->meta_description != null) ? "":"d-none"); ?>">
                        <div class="form-group bmd-form-group">
                            <label for="meta_description" class="bmd-label-floating"><?php echo e(__('Meta Description')); ?></label>
                        <input type="text" class="form-control" id="meta_description" name="meta_description" value="<?php echo e($data->meta_description); ?>">
                            <span class="bmd-help"><?php echo e(__('Meta Description')); ?></span>
                        </div>
                      </div>

                      <div class="col-lg-12">
                        <label><?php echo e(__('Close Campaign After')); ?>*</label>
                        <div class="radio pb-1">
                          <label class="pt-2 pb-2 pr-3"><input type="radio" class="mr-2" <?php echo e($data->end_after =='goal' ? 'checked' : ''); ?> name="end_after" value="goal"><?php echo e(__('Achieving Goal')); ?></label>
                          <label><input type="radio" name="end_after"  class="mr-2" <?php echo e($data->end_after =='date' ? 'checked' : ''); ?>  value="date"><?php echo e(__('End Date')); ?></label>
                        </div>
                      </div>

                      <div class="col-lg-12">
                        <div class="checkbox pb-4">
                          <label class="pt-2 pt-2 pr-3"><input type="checkbox" class="mr-2" <?php echo e($data->featured ==1 ? 'checked' : ''); ?>  name="featured" value="1"> <?php echo e(__('Add to Featured Campaign')); ?></label>
                          <label><input type="checkbox" class="mr-2" name="send_newsletter" <?php echo e($data->send_newsletter ==1 ? 'checked' : ''); ?> value="1"> <?php echo e(__('Send NewsLetter to all Subscribers')); ?></label>
                        </div>
                      </div>
                      
                      <div class="col-lg-12">
                          <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Update')); ?></button>
                      </div>
                  </div>
              </form>
          </div>
        </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script>
 var dateToday = new Date();
  var dates =  $( "#end_date" ).datepicker({
      changeMonth: true,
      changeYear: true,
      minDate: dateToday,
});

$('.tags').tagify();
$('.preloaded_amount').tagify();


$('#allowProductSEO').on('click',function(){

let value = $(this).is(':checked');
if(value == false){
  $('.showMetaData').addClass('d-none');
}else{
  $('.showMetaData').removeClass('d-none');
}
})

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/muktooxy/public_html/project/resources/views/user/campaign/edit.blade.php ENDPATH**/ ?>