


<?php $__env->startSection('content'); ?>
<div class="col-lg-9">

    <div class="transaction-area">
        <div class="heading-area">
            <h3 class="title">
               <?php echo e(__('Withdraw Now')); ?>

                <a href="<?php echo e(route('user-wwt-index')); ?>" class="btn btn-primary btn-round ml-2"><?php echo e(__('Back')); ?></a>
              </h3>
        </div>

        <div class="gocover" style="background: url(<?php echo e(asset('assets/images/'.$gs->loader)); ?>) no-repeat scroll center center rgba(45, 45, 45, 0.5);"></div>
        <form id="userform" class="form-horizontal px-4" action="<?php echo e(route('user-wwt-store')); ?>" method="POST" enctype="multipart/form-data">

            <?php echo e(csrf_field()); ?> <?php echo $__env->make('includes.admin.form-both', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="row">
                <label class="text-muted text-success  ShowFund "></label>
                <div class="col-lg-12">
                    <div class="form-group bmd-form-group">
                        <select name="methods" id="withmethod" class="form-control" required>
                            <option value=""><?php echo e(__('Select Withdraw Method')); ?></option>
                            <option value="Paypal"><?php echo e(__('bKash')); ?></option>
                            <option value="Skrill"><?php echo e(__('Rocket')); ?></option>
                            <option value="Payoneer"><?php echo e(__('Nagad')); ?></option>
                            <option value="Bank"><?php echo e(__('Bank')); ?></option>
                        </select>
                    </div>
                </div>

                <div class="col-lg-12">
                    <div class="form-group bmd-form-group">
                        <select name="campaign_id" id="campaign_id" class="form-control" required>
                            <option selected value="<?php echo e(Auth::user()->campaign()->first()->id); ?>">
                                <?php echo e(Auth::user()->campaign()->first()->campaign_name); ?></option>
                            <?php $__currentLoopData = Auth::user()->campaign()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($key != 0): ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->campaign_name); ?></option> 
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                

                <div class="col-lg-12">
                    <div class="form-group bmd-form-group">
                        <label for="amount" class="bmd-label-floating"><?php echo e(__('Withdraw Amount')); ?>* (<?php echo e($currencies->name); ?>)</label>
                        <input name="amount" id="amount" class="form-control" autocomplete="off" type="text" value="<?php echo e(old('amount')); ?>" required>
                        <span class="bmd-help"><?php echo e(__('Withdraw Amount')); ?> (<?php echo e($currencies->name); ?>)</span>
                    </div>
                </div>

                <div id="paypal" style="display: none; width: 100%;">

                    <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="acc_email" class="bmd-label-floating"><?php echo e(__('Enter Account Number')); ?>*</label>
                            <input name="acc_email" id="acc_email" class="form-control" type="text" value="<?php echo e(old('acc_email')); ?>" required>
                            <span class="bmd-help"><?php echo e(__('Enter Account Number')); ?></span>
                        </div>
                    </div>

                </div>

                <div id="bank" style="display: none; width: 100%;">

                    <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="iban" class="bmd-label-floating"><?php echo e(__('Enter Account No')); ?>*</label>
                            <input name="iban" id="iban" class="form-control" type="text" value="<?php echo e(old('iban')); ?>" required>
                            <span class="bmd-help"><?php echo e(__('Enter IBAN/Account No')); ?></span>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="accname" class="bmd-label-floating"><?php echo e(__('Enter Account Name')); ?>*</label>
                            <input name="accname" id="accname" class="form-control" type="text" value="<?php echo e(old('accname')); ?>" required>
                            <span class="bmd-help"><?php echo e(__('Enter Account Name')); ?></span>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="address" class="bmd-label-floating"><?php echo e(__('Enter Address')); ?>*</label>
                            <input name="address" id="address" class="form-control" type="text" value="<?php echo e(old('address')); ?>" required>
                            <span class="bmd-help"><?php echo e(__('Enter Address')); ?></span>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="form-group bmd-form-group">
                            <label for="swift" class="bmd-label-floating"><?php echo e(__('Enter Swift Code')); ?>*</label>
                            <input name="swift" id="swift" class="form-control" type="text" value="<?php echo e(old('swift')); ?>" required>
                            <span class="bmd-help"><?php echo e(__('Enter Swift Code')); ?></span>
                        </div>
                    </div>

                </div>

                <div class="col-lg-12">
                    <div class="form-group bmd-form-group">
                        <label for="reference" class="bmd-label-floating"><?php echo e(__('Additional Reference(Optional)')); ?> </label>
                        <textarea id="reference" class="form-control" name="reference" rows="6"><?php echo e(old('reference')); ?></textarea>
                        <span class="bmd-help"><?php echo e(__('Additional Reference(Optional)')); ?></span>
                    </div>
                </div>
                <div id="resp" class="col-md-12">
                    <span class="help-block">
                            <strong><?php echo e(__('Withdraw Fee')); ?>  $<?php echo e($gs->withdraw_fee); ?> <?php echo e(__('and')); ?>  <?php echo e($gs->withdraw_charge); ?>% <?php echo e(__('will deduct from your account')); ?>.</strong>
                        </span>
                </div>

                <div class="col-lg-12">
                    <button type="submit" class="btn btn-primary btn-round"><?php echo e(__('Withdraw Now')); ?></button>
                </div>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<script type="text/javascript">
    $("#withmethod").change(function(){
        var method = $(this).val();
        if(method == "Bank"){

            $("#bank").show();
            $("#bank").find('input, select').attr('required',true);

            $("#paypal").hide();
            $("#paypal").find('input').attr('required',false);

        }
        if(method != "Bank"){
            $("#bank").hide();
            $("#bank").find('input, select').attr('required',false);

            $("#paypal").show();
            $("#paypal").find('input').attr('required',true);
        }
        if(method == ""){
            $("#bank").hide();
            $("#paypal").hide();
        }

    })

</script>

<script>
   var value = $('#campaign_id :selected').val();
        $.ajax({
            type: "get",
            url: '<?php echo e(url('user/campaign/availble-fund/get')); ?>/' + value,
            success: function(data)
            {
                $('.ShowFund').html(data);
            }
            });

    $('#campaign_id').on('change',function(){
        var value = $('#campaign_id :selected').val();
        $.ajax({
            type: "get",
            url: '<?php echo e(url('user/campaign/availble-fund/get')); ?>/' + value,
            success: function(data)
            {
                $('.ShowFund').html(data);
            }
            });
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Mukto\project\resources\views/user/withdraw/withdraw.blade.php ENDPATH**/ ?>