<?php $__env->startSection('content'); ?>
<!-- Breadcrumb Area Start -->

<div class="breadcrumb-area" style="background: url(<?php echo e($gs->breadcumb_banner ? asset('assets/images/'.$gs->breadcumb_banner) : ''); ?>);">
    <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <?php if(isset($_GET['search'])): ?>
                <div class="col-lg-12">
                    <h1 class="pagetitle">
                        <?php echo e(__('Search For :')); ?> <?php echo e($_GET['search']); ?>

                    </h1>
                    <ul class="pages">
                        <li>
                            <a href="<?php echo e(route('front.index')); ?>">
                                <?php echo e(__('Home')); ?>

                            </a>
                        </li>
                        <li class="active">
                            <a href="javascript:;">
                                <?php echo e(__('Search')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
                <?php else: ?>

                <div class="col-lg-12">
                    <h1 class="pagetitle">
                        <?php echo e(__('Campaign')); ?>

                    </h1>
                    <ul class="pages">
                        <li>
                            <a href="<?php echo e(route('front.index')); ?>">
                                <?php echo e(__('Home')); ?>

                            </a>
                        </li>
                        <li class="active">
                            <a href="<?php echo e(route('front.campaign')); ?>">
                                <?php echo e(__('Campaign')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- Breadcrumb Area End -->

    <!-- Causes Area Start -->
<section class="causes-page">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                    <?php
                    $count = 0;
                    ?>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(Carbon\Carbon::now() < Carbon\Carbon::parse($data->end_date) && $data->end_after == 'date'): ?>
                            <?php
                            $count =1;
                        ?>

                <div class="col-md-6">
                    <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>" class="item">
                        <div class="single-causes">
                            <div class="img">
                                <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                            </div>
                            <div class="content">
                                <span data-href="<?php echo e(route('front.campaign.donet',$data->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                <h4 class="title">
                                    <?php echo e($data->campaign_name); ?>

                                </h4>
                                <p class="text">
                                    <?php echo e(substr(strip_tags($data->description),0,100)); ?>

                                </p>

                                    <div class="progress-area">
                                        <div class="persentage">
                                            <span><?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar  p-1" style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                    <div class="top-meta mt-3">
                                        <div class="left">
                                                <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($data->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                        </div>
                                        <div class="right">
                                            <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($data->goal * $currencies->value ,2)); ?> </span>
                                        </div>
                                    </div>


                            </div>
                        </div>
                    </a>
                </div>

            <?php elseif($data->goal > $data->available_fund && $data->end_after == 'goal'): ?>
                <?php
                $count = 1;
                ?>
                <div class="col-md-6">
                    <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>" class="item">
                        <div class="single-causes">
                            <div class="img">
                                <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                            </div>
                            <div class="content">
                                <span data-href="<?php echo e(route('front.campaign.donet',$data->slug)); ?>" class="mybtn1 donateBtn"><?php echo e(__('Donate Now')); ?></span>
                                <h4 class="title">
                                    <?php echo e($data->campaign_name); ?>

                                </h4>
                                <p class="text">
                                    <?php echo e(substr(strip_tags($data->description),0,100)); ?>

                                </p>

                                    <div class="progress-area">
                                        <div class="persentage">
                                            <span><?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%</span>
                                        </div>
                                        <div class="progress">
                                            <div class="progress-bar  p-1" style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%" role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                    <div class="top-meta mt-3">
                                        <div class="left">
                                                <?php echo e(__('Raised')); ?>: <span><?php echo e($currencies->sign); ?> <?php echo e(round($data->donation->sum('donation_amount') * $currencies->value ,2)); ?></span>
                                        </div>
                                        <div class="right">
                                            <?php echo e(__('Goal')); ?> : <span><?php echo e($currencies->sign); ?> <?php echo e(round($data->goal * $currencies->value ,2)); ?> </span>
                                        </div>
                                    </div>


                            </div>
                        </div>
                    </a>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($count == 0): ?>
<section class="causes-details-page">
    <div class="container">
        <div class="row">
            <div class="">
                <h2 class="text-center"><?php echo e(__('No Campaign Found')); ?></h2>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
</div>


<div class="page-center">
    <?php if(isset($_GET['search'])): ?>
      <?php echo e($datas->appends(['search' => $_GET['search']])->links()); ?>

    <?php else: ?>
      <?php echo e($datas->links()); ?>

    <?php endif; ?>
</div>

</div>
<div class="col-lg-4">
    <div class="recent-causes-widget">
        <h4 class="title">
            <?php echo e(__('Latest Campaign')); ?>

        </h4>
        <span class="separator"></span>
        <ul class="post-list">
            <?php $__currentLoopData = $latesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if(Carbon\Carbon::now() < Carbon\Carbon::parse($data->end_date) && $data->end_after == 'date'): ?>

                <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                    <li>
                        <div class="post">
                            <div class="post-img">
                                <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                            </div>
                            <div class="post-details">
                                <h4 class="post-title">
                                    <?php echo e($data->campaign_name); ?>

                                    <p class="time-left">
                                        - (<?php echo e($data->end_date); ?>)
                                    </p>
                                </h4>



                                <div class="progress-area">
                                    <div class="persentage">
                                        <?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar  p-1"
                                            style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%"
                                            role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </a>
                <?php elseif($data->goal > $data->available_fund && $data->end_after == 'goal'): ?>
                <a href="<?php echo e(route('front.campaign.show',$data->slug)); ?>">
                    <li>
                        <div class="post">
                            <div class="post-img">
                                <img src="<?php echo e(asset('assets/images/campaign/'.$data->photo)); ?>" alt="">
                            </div>
                            <div class="post-details">

                                <h4 class="post-title">
                                    <?php echo e($data->campaign_name); ?>

                                    <p class="time-left">
                                       - (<?php echo e($data->end_date); ?>)
                                    </p>
                                </h4>



                                <div class="progress-area">
                                    <div class="persentage">
                                        <?php echo e(round($data->donation->sum('donation_amount') / $data->goal * 100, 2) > 100.00  ? '100' : round($data->donation->sum('donation_amount') / $data->goal * 100, 2)); ?>%
                                    </div>
                                    <div class="progress">
                                        <div class="progress-bar  p-1"
                                            style="width:<?php echo e(($data->donation->sum('donation_amount') / $data->goal * 100)); ?>%"
                                            role="progressbar" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                </a>

                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if($count == 0): ?>
                <li>
                    <div class="post">
                        <div class="post-details">
                            <h4 class="post-title text-center">
                                <?php echo e(__('No Campaign')); ?>

                            </h4>
                        </div>
                    </div>
                </li>
                <?php endif; ?>
        </ul>
    </div>





    <div class="categori-widget">
        <h4 class="title"><?php echo e(__('Categories')); ?></h4>
        <span class="separator"></span>
        <ul class="categori-list">
            <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $count = 0;
            foreach ($item->campaigns->where('status','open')->where('is_panding',1) as $key => $value) {
            if($value->goal > $value->available_fund && $value->end_after == 'goal'){
            $count++;
            }elseif(Carbon\Carbon::now() < Carbon\Carbon::parse($value->end_date) && $value->end_after ==
                'date'){
                $count++;
                }
            }
            ?>
            <?php if($count != 0): ?>
            <li>
                <a href="<?php echo e(route('front.campaign.category',$item->slug)); ?>" <?php echo $item->slug == Request::route('slug') ?
                    'class="active"':''; ?> >
                    <span><?php echo e($item->name); ?></span>
                    <span>(<?php echo e($count); ?>)</span>
                </a>
            </li>
            <?php endif; ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <div class="tags-widget">
        <h4 class="title"><?php echo e(__('Tags')); ?></h4>
        <span class="separator"></span>
        <ul class="tags-list">

            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($tag): ?>
            <li>
                <a href="<?php echo e(route('front.campaign.slug',$tag)); ?>" <?php echo $tag==Request::route('slug') ? 'class="active"'
                    :''; ?>><?php echo e($tag); ?> </a>
            </li>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>




</div>
</div>
</section>


<!-- Causes Area End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/work/charity_7/project/resources/views/front/campaign.blade.php ENDPATH**/ ?>